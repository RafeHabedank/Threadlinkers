#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <math.h>

#include "header1.h"

using namespace std;

// http://pastebin.com/D6VqiiXw
// docLocation
// /wayfinders
// Created by Rafe Habedank

//Controls:
// wasd move the character (The "R" symbol)
// arrow keys move your selecting cursor
// Q & E toggle the block you are trying to place
// shift digs/places blocks
// F opens your inventory
// you can only place blocks if you have them in your inventory
// "g" is save

void ClearScreen() // NOTE: i did not make the following function I got it from: "http://www.cplusplus.com/articles/4z18T05o/"
{
  HANDLE                     hStdOut;
  CONSOLE_SCREEN_BUFFER_INFO csbi;
  DWORD                      count;
  DWORD                      cellCount;
  COORD                      homeCoords = { 0, 0 };

  hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );
  if (hStdOut == INVALID_HANDLE_VALUE) return;

  /* Get the number of cells in the current buffer */
  if (!GetConsoleScreenBufferInfo( hStdOut, &csbi )) return;
  cellCount = csbi.dwSize.X *csbi.dwSize.Y;

  /* Fill the entire buffer with spaces */
  if (!FillConsoleOutputCharacter(
    hStdOut,
    (TCHAR) ' ',
    cellCount,
    homeCoords,
    &count
    )) return;

  /* Fill the entire buffer with the current colors and attributes */
  if (!FillConsoleOutputAttribute(
    hStdOut,
    csbi.wAttributes,
    cellCount,
    homeCoords,
    &count
    )) return;

  /* Move the cursor home */
  SetConsoleCursorPosition( hStdOut, homeCoords );

}

void moveCursor(int posX, int posY)
{
    HANDLE hStdOut;
    COORD posXY = {posX, posY};

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );
    SetConsoleCursorPosition(hStdOut, posXY);
}

int getKey()
{
    while(true)
    for(int i = 8; i <= 256; i++)
    {
        if(GetAsyncKeyState(i))
        {
                return i;
        }
    }
};

int waitForKey()
{
    while(true)
    {
        for(int i = 8; i <= 256; i++)
        {
            if(GetAsyncKeyState(i))
            {
                return i;
            }
        }
    }
}

bool keyPressed(int input)
{
    if(GetAsyncKeyState(input))
    {
        return true;
    }
    else
    {
        return false;
    }
};
