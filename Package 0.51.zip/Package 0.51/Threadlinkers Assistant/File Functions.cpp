#include "header1.h"

using namespace std;


string cutString(string source, int startPos, int endPos)
{
    string output = "";

    if(endPos > source.size())
    {
        endPos = source.size() - 1;
    }
    for(int i = startPos; i <= endPos; i++)
    {
        output += source[i];
    }
    return output;
};


string simpleIntToString(int input) /// Thus function sucks ass, make sure to write a better one
{
    if(input == 0)
    {
        return "0";
    }
    else if(input == 1)
    {
        return "1";
    }
    else if(input == 2)
    {
        return "2";
    }
    else if(input == 3)
    {
        return "3";
    }
    else if(input == 4)
    {
        return "4";
    }
    else if(input == 5)
    {
        return "5";
    }
    else if(input == 6)
    {
        return "6";
    }
    else if(input == 7)
    {
        return "7";
    }
    else if(input == 8)
    {
        return "8";
    }
    else if(input == 9)
    {
        return "9";
    }
    else if(input == 10)
    {
        return "10";
    }
    else if(input == 11)
    {
        return "11";
    }
    else if(input == 12)
    {
        return "12";
    }
    else
    {
        return "E";
    }
};

string intToString(int input)
{
    /// Make sure to write this for later
}

int stringToInt(string input)
{
    /// NOTE NOTE    pow() does NOT always play nice with int values, some sort of rounding error within the code that can cause
    ///issues when you append it to another integer value. Use float values if you want to be safe.
    int girth = input.size();
    double number = 0;
    //cout << "Input to function: " << input << endl;
    //cout << "Size of input string: " << girth << endl; some debugging code
    //cout << "position 2 = " << input[2] << endl;

    //string output = input;

    //string cleanSource = "";

    //for(int i = 0; i < output.size(); i++)
    //{
        //if(output[i] == '0' || output[i] == '1' || output[i] == '2' || output[i] == '3' || output[i] == '4' || output[i] == '5' || output[i] == '6' || output[i] == '7' || output[i] == '8' || output[i] == '9')
        //{
            //cleanSource += output[i];
        //}
    //}

    //input = cleanSource;


    for(int i = 0; i < girth +2; ++i)
    {
        if(input[girth-i-1] == '1')
        {
            float x = pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '2')
        {
            float x = 2 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '3')
        {
            float x = 3 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '4')
        {
            float x = 4 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '5')
        {
            float x = 5 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '6')
        {
            float x = 6 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '7')
        {
            float x = 7 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '8')
        {
            float x = 8 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '9')
        {
            float x = 9 * pow(10,i);
            number += x;
        }
        if(input[girth-i-1] == '-')
        {
            number -= 2 * number;
            i = 1000;
        }
    }
    return (int)number;
};

// Function that gets the cost for a spell considering different factors
// Imputs include the spells name, level, player's personality colors, and known spells
int getCost(string spellName, int spellLevel, bool playerColors[6], vector<string> knownSpells)
{
    string level = simpleIntToString(spellLevel);

    string output;

    //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + level + "/" + spellName + ".txt"); /// MAKE SURE TO UPDATE NAME
    ifstream inFile("../Threadlinkers Assistant/Spells/" + level + "/" + spellName + ".txt");
    getline(inFile,output);
    getline(inFile,output);

    int stringSize = output.size();

    string initialCost = "";

    for(int i = 0; i < stringSize; i++)
    {
        if(output[i] == ':')
        {
            i += 2;
            for(; i < stringSize; i++)
            {
                initialCost += output[i];
            }
        }
    }
    int cost = stringToInt(initialCost);

    /// =========================================================================

    getline(inFile,output);
    stringSize = output.size();

    for(int i = 0; i < stringSize; i++)
    {
        //cout << i << endl;
        if(output[i] == ',')
        {
            i += 2;
            int startPos = i;
            int endPos = 0;
            bool loop = true;
            while(loop)
            {
                if(output[i] == '(')
                {
                    endPos = i - 2;
                    //i--;
                    loop = false;
                }
                i++;
            }
            string suppName = "";
            suppName = cutString(output,startPos,endPos);
            //cout << "detected name of: " << suppName << '/' << endl;

            int numStart;
            int numEnd;

            //cout << knownSpells.size() << endl;

            for(int x = 0; x < knownSpells.size(); x++)
            {
                //cout << "known spell " << x << ": " << knownSpells[x] << "/" << endl;
                if(knownSpells[x] == suppName)
                {
                    //cout << "Applied supplements: " << suppName << " spell number " << x << endl;
                    i = endPos + 3; /// FIX THIS FIX THIS FIX THIS FIX THIS
                    numStart = i;
                    bool loop2 = true;
                    while(loop2)
                    {
                        if(output[i] == ')')
                        {
                            numEnd = i - 1;
                            loop2 = false;
                            break;
                        }
                        i++;
                    }
                    string numString = cutString(output, numStart, numEnd);
                    //cout << numString << endl;
                    int suppMod = stringToInt(numString);
                    cost += suppMod;
                }
            }
        }
    }
    /// ===========================================================
    getline(inFile, output);
    getline(inFile, output); /// Skipping two lines here due to formatting of the document

    for(int i = 0; i < NUMBER_OF_COLORS; i++)
    {
        getline(inFile, output);


        if(playerColors[i] == true)
        {
            int stringSize = output.size();
            int numStart;
            int numEnd;

            for(int x = 0; x < stringSize; x++)
            {
                if(output[x] == ':')
                {
                    x += 2;
                    numStart = x;
                    numEnd = stringSize - 1;
                    break;
                }
            }
            string numString = cutString(output, numStart, numEnd);
            int suppMod = stringToInt(numString);
            cost += suppMod;
        }
    }
    inFile.close();
    return cost;
}

void player::loadData()
{
   //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Characters/" + name + ".txt"); /// MAKE SURE TO UPDATE THIS WHENEVER THE LOCATION CHANGES
   ifstream inFile("../Threadlinkers Assistant/Characters/" + name + ".txt");
   if(inFile.fail())
   {
       cout << "FAILURE TO LOAD CHARACTER FILE. CHECK FILE INTEGRITY AND REBOOT." << endl;
       while(true)
       {

       }
   }
   else
   {
       //cout << "LOADED: " << name << ".txt" << endl;
   }

   //cout << "Loading data" << endl;
   string output;

   for(int i = 0; i < 4; i++)
   {
       getline(inFile, output); /// Skipping some lines due to formatting
   }
   getline(inFile, race); /// Load race
   //cout << race << endl;

   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   age = stringToInt(output); /// Load age
   //cout << age << endl;

   getline(inFile, output);
   getline(inFile, output);

   for(int i = 0; i < 2; i++)
   {
       getline(inFile, output);
       if(output == "White")
       {
           colors[0] = true;
           //cout << "White" << endl;
       }
       if(output == "Black")
       {
           colors[1] = true;
           //cout << "Black" << endl;
       }
       if(output == "Blue")
       {
           colors[2] = true;
           //cout <<  "Blue" << endl;
       }
       if(output == "Green")
       {
           colors[3] = true;
           //cout << "Green" << endl;
       }
       if(output == "Red")
       {
           colors[4] = true;
           //cout << "Red" << endl;
       }
       if(output == "Brown")
       {
           colors[5] = true;
           //cout << "Brown" << endl;
       }
   }
   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   totalSkillPoints = stringToInt(output); /// Loading total Skill Points

   //cout << "Total Skill points: " << totalSkillPoints << endl;

   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   spareSkillPoints = stringToInt(output); /// Loading spare Skill Points

   getline(inFile, output);
   getline(inFile, output);
   ///
   getline(inFile,output);
   sparePhysicalStatPoints = stringToInt(output);
   getline(inFile, output);
   getline(inFile, output);

   getline(inFile,output);
   spareMentalStatPoints = stringToInt(output);

   getline(inFile, output);
   getline(inFile, output);

   ///

   for(int i = 0; i < 6; i++) /// Loading the main 6 stats
   {
        getline(inFile, output);
        stats[i] = stringToInt(output);
        //cout << statNames[i] << stats[i] << endl;

        getline(inFile, output);
        getline(inFile, output);
   }

   /// Loading Skill Values

   int cutPoint = 0;
       for(int x = output.size() - 1; x > 0; x--)
       {
           if(output[x] == ' ')
           {
               cutPoint = x + 1;
               break;
           }
       }
       skills[0] = stringToInt(cutString(output, cutPoint, output.size() - 1));
       //cout << 0 << " /" << cutString(output, cutPoint, output.size() - 1) << "/ " << stringToInt(cutString(output, cutPoint, output.size() - 1)) << endl;

   for(int i = 1; i < 39; i++)
   {
       //cout << "flag" << endl;
       getline(inFile, output);
       int cutPoint = 0;
       for(int x = output.size() - 1; x > 0; x--)
       {
           if(output[x] == ' ')
           {
               cutPoint = x + 1;
               break;
           }
       }
       skills[i] = stringToInt(cutString(output, cutPoint, output.size() - 1));
       //cout << i << " /" << cutString(output, cutPoint, output.size() - 1) << "/ " << stringToInt(cutString(output, cutPoint, output.size() - 1)) << endl;
   }

   getline(inFile, output);
   getline(inFile, output);

   ///

   maxHealth = totalSkillPoints / 10; /// Calculating Health

   getline(inFile, output);

   bool loop = true;
   int phase = 1;

   int nextSpellLevel = 0;

   spellListSIMPLE.clear();

   for(int i = 0; i < 10; i++)
   {
       spells[i].clear();
   }

   while(loop) /// LOADING SPELLS
   {
       getline(inFile, output);
       //cout << "phase: " << phase << "  " << output << endl << endl;
       if(output == "/END" || output == "/CYBERWARE")
       {
           break;
       }

       if(phase == 1)
       {
           nextSpellLevel = stringToInt(output);
           //spells.push_back(output);
       }
       if(phase == 2)
       {
           spells[nextSpellLevel].push_back(output);
           spellListSIMPLE.push_back(output);
       }
       if(phase == 3)
       {
           spellCosts[nextSpellLevel].push_back(stringToInt(output));
           pointsSpentOnSpells += stringToInt(output);
       }

       if(phase == 1 || phase == 2)
       {
           phase++;
       }
       else
       {
           phase = 1;
       }
   }

   phase = 1;

   augmentListSIMPLE.clear();

   for(int i = 0; i < 13; i++)
   {
       augments[i].clear();
   }

   while(loop) /// LOADING CYBERNETICS
   {
       getline(inFile, output);
       //cout << "phase: " << phase << "  " << output << endl << endl;
       if(output == "/END")
       {
           break;
       }

       if(phase == 1)
       {
           nextSpellLevel = stringToInt(output);
           //spells.push_back(output);
       }
       if(phase == 2)
       {
           augments[nextSpellLevel].push_back(output);
           augmentListSIMPLE.push_back(output);
       }
       if(phase == 3)
       {
           augmentPointCosts[nextSpellLevel].push_back(stringToInt(output));
       }
       if(phase == 4)
       {
           augmentSpiritCosts[nextSpellLevel].push_back(stringToInt(output));
           cumulativeSpiritPenalty += stringToInt(output);
       }
       if(phase == 5)
       {
           if(output == "true" || output == "1")
           {
               augmentActive[nextSpellLevel].push_back(true);
           }
           else
           {
               augmentActive[nextSpellLevel].push_back(false);
           }
       }

       if(phase == 1 || phase == 2 || phase == 3 || phase == 4)
       {
           phase++;
       }
       else
       {
           phase = 1;
       }
   }

   ClearScreen();

   stats[6] = 50+totalSkillPoints / 20; /// Calculating initial spirit value. Real calculation happens in the add spell points function.
};

bool player::loadBackground(string backgroundName) /// Changed line
{
   ifstream inFile("../Threadlinkers Assistant/Characters/Backgrounds/" + backgroundName + ".txt"); /// Changed line
   if(inFile.fail())
   {
       return false;
   }
   else
   {
       //cout << "LOADED: " << name << ".txt" << endl;
   }

   //cout << "Loading data" << endl;
   string output;

   for(int i = 0; i < 4; i++)
   {
       getline(inFile, output); /// Skipping some lines due to formatting
   }
   getline(inFile, race); /// Load race
   //cout << race << endl;

   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   age = stringToInt(output); /// Load age
   //cout << age << endl;

   getline(inFile, output);
   getline(inFile, output);

   for(int i = 0; i < 2; i++)
   {
       getline(inFile, output);
       if(output == "White")
       {
           //colors[0] = true;
           //cout << "White" << endl;
       }
       if(output == "Black")
       {
           //colors[1] = true;
           //cout << "Black" << endl;
       }
       if(output == "Blue")
       {
           //colors[2] = true;
           //cout <<  "Blue" << endl;
       }
       if(output == "Green")
       {
           //colors[3] = true;
           //cout << "Green" << endl;
       }
       if(output == "Red")
       {
           //colors[4] = true;
           //cout << "Red" << endl;
       }
       if(output == "Brown")
       {
           //colors[5] = true;
           //cout << "Brown" << endl;
       }
   }
   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   totalSkillPoints = stringToInt(output); /// Loading total Skill Points

   //cout << "Total Skill points: " << totalSkillPoints << endl;

   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   spareSkillPoints = stringToInt(output); /// Loading spare Skill Points

   getline(inFile, output);
   getline(inFile, output);
   ///
   getline(inFile,output);
   sparePhysicalStatPoints = stringToInt(output);
   getline(inFile, output);
   getline(inFile, output);

   getline(inFile,output);
   spareMentalStatPoints = stringToInt(output);

   getline(inFile, output);
   getline(inFile, output);

   ///

   for(int i = 0; i < 6; i++) /// Loading the main 6 stats
   {
        getline(inFile, output);
        stats[i] = stringToInt(output);
        //cout << statNames[i] << stats[i] << endl;

        getline(inFile, output);
        getline(inFile, output);
   }

   /// Loading Skill Values

   int cutPoint = 0;
       for(int x = output.size() - 1; x > 0; x--)
       {
           if(output[x] == ' ')
           {
               cutPoint = x + 1;
               break;
           }
       }
       skills[0] = stringToInt(cutString(output, cutPoint, output.size() - 1));
       //cout << 0 << " /" << cutString(output, cutPoint, output.size() - 1) << "/ " << stringToInt(cutString(output, cutPoint, output.size() - 1)) << endl;

   for(int i = 1; i < 39; i++)
   {
       //cout << "flag" << endl;
       getline(inFile, output);
       int cutPoint = 0;
       for(int x = output.size() - 1; x > 0; x--)
       {
           if(output[x] == ' ')
           {
               cutPoint = x + 1;
               break;
           }
       }
       skills[i] = stringToInt(cutString(output, cutPoint, output.size() - 1));
       //cout << i << " /" << cutString(output, cutPoint, output.size() - 1) << "/ " << stringToInt(cutString(output, cutPoint, output.size() - 1)) << endl;
   }

   getline(inFile, output);
   getline(inFile, output);

   ///

   maxHealth = totalSkillPoints / 10; /// Calculating Health

   getline(inFile, output);

   bool loop = true;
   int phase = 1;

   int nextSpellLevel = 0;

   spellListSIMPLE.clear();

   for(int i = 0; i < 10; i++)
   {
       spells[i].clear();
   }

   while(loop) /// LOADING SPELLS
   {
       getline(inFile, output);
       //cout << "phase: " << phase << "  " << output << endl << endl;
       if(output == "/END" || output == "/CYBERWARE")
       {
           break;
       }

       if(phase == 1)
       {
           nextSpellLevel = stringToInt(output);
           //spells.push_back(output);
       }
       if(phase == 2)
       {
           spells[nextSpellLevel].push_back(output);
           spellListSIMPLE.push_back(output);
       }
       if(phase == 3)
       {
           spellCosts[nextSpellLevel].push_back(stringToInt(output));
           pointsSpentOnSpells += stringToInt(output);
       }

       if(phase == 1 || phase == 2)
       {
           phase++;
       }
       else
       {
           phase = 1;
       }
   }

   phase = 1;

   while(loop) /// LOADING CYBERNETICS
   {
       getline(inFile, output);
       //cout << "phase: " << phase << "  " << output << endl << endl;
       if(output == "/END")
       {
           break;
       }

       if(phase == 1)
       {
           nextSpellLevel = stringToInt(output);
           //spells.push_back(output);
       }
       if(phase == 2)
       {
           augments[nextSpellLevel].push_back(output);
           augmentListSIMPLE.push_back(output);
       }
       if(phase == 3)
       {
           augmentPointCosts[nextSpellLevel].push_back(stringToInt(output));
       }
       if(phase == 4)
       {
           augmentSpiritCosts[nextSpellLevel].push_back(stringToInt(output));
           cumulativeSpiritPenalty += stringToInt(output);
       }
       if(phase == 5)
       {
           if(output == "true" || output == "1")
           {
               augmentActive[nextSpellLevel].push_back(true);
           }
           else
           {
               augmentActive[nextSpellLevel].push_back(false);
           }
       }

       if(phase == 1 || phase == 2 || phase == 3 || phase == 4)
       {
           phase++;
       }
       else
       {
           phase = 1;
       }
   }

   ClearScreen();

   stats[6] = 50+totalSkillPoints / 20; /// Calculating initial spirit value. Real calculation happens in the add spell points function.

   return true;
};

bool player::spliceFile(string filePath, string name, float fraction)
{
   ifstream inFile(filePath + name + ".txt");

   cout << "FLAG 114" << endl;

   if(inFile.fail())
   {
       while(true)
       {
           cout << "AHHHHHHHH" << endl;
       }
       return false;
   }

   cout << "FLAG 113" << endl;

   string output;

   for(int i = 0; i < 4; i++)
   {
       getline(inFile, output); /// Skipping some lines due to formatting
   }
   getline(inFile, race); /// Load race
   //cout << race << endl;

   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   age += stringToInt(output) * fraction; /// Load age
   //cout << age << endl;

   getline(inFile, output);
   getline(inFile, output);

   for(int i = 0; i < 2; i++)
   {
       getline(inFile, output);
       if(output == "White")
       {
           //colors[0] = true;
           //cout << "White" << endl;
       }
       if(output == "Black")
       {
           //colors[1] = true;
           //cout << "Black" << endl;
       }
       if(output == "Blue")
       {
           //colors[2] = true;
           //cout <<  "Blue" << endl;
       }
       if(output == "Green")
       {
           //colors[3] = true;
           //cout << "Green" << endl;
       }
       if(output == "Red")
       {
           //colors[4] = true;
           //cout << "Red" << endl;
       }
       if(output == "Brown")
       {
           //colors[5] = true;
           //cout << "Brown" << endl;
       }
   }

   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   totalSkillPoints += stringToInt(output) * fraction; /// Loading total Skill Points

   //cout << "Total Skill points: " << totalSkillPoints << endl;

   getline(inFile, output);
   getline(inFile, output);

   getline(inFile, output);
   spareSkillPoints += stringToInt(output) * fraction; /// Loading spare Skill Points

   getline(inFile, output);
   getline(inFile, output);
   ///
   getline(inFile,output);
   sparePhysicalStatPoints += stringToInt(output) * fraction;
   getline(inFile, output);
   getline(inFile, output);

   getline(inFile,output);
   spareMentalStatPoints += stringToInt(output) * fraction;

   getline(inFile, output);
   getline(inFile, output);

   ///


   for(int i = 0; i < 6; i++) /// Loading the main 6 stats
   {
        getline(inFile, output);
        stats[i] += stringToInt(output) * fraction;
        //cout << statNames[i] << stats[i] << endl;

        getline(inFile, output);
        getline(inFile, output);
   }

   /// Loading Skill Values

   int cutPoint = 0;
       for(int x = output.size() - 1; x > 0; x--)
       {
           if(output[x] == ' ')
           {
               cutPoint = x + 1;
               break;
           }
       }
       skills[0] += stringToInt(cutString(output, cutPoint, output.size() - 1)) * fraction;
       //cout << 0 << " /" << cutString(output, cutPoint, output.size() - 1) << "/ " << stringToInt(cutString(output, cutPoint, output.size() - 1)) << endl;

       cout << "FLAG B" << endl;

   for(int i = 1; i < 39; i++)
   {
       //cout << "flag" << endl;
       getline(inFile, output);
       int cutPoint = 0;
       for(int x = output.size() - 1; x > 0; x--)
       {
           if(output[x] == ' ')
           {
               cutPoint = x + 1;
               break;
           }
       }
       skills[i] += stringToInt(cutString(output, cutPoint, output.size() - 1)) * fraction;
       //cout << i << " /" << cutString(output, cutPoint, output.size() - 1) << "/ " << stringToInt(cutString(output, cutPoint, output.size() - 1)) << endl;
   }

   getline(inFile, output);
   getline(inFile, output);

   ///

   maxHealth = totalSkillPoints / 10; /// Calculating Health

   getline(inFile, output);

   bool loop = true;
   int phase = 1;

   int nextSpellLevel = 0;

   //spellListSIMPLE.clear();

   //for(int i = 0; i < 10; i++)
   //{
       //spells[i].clear();
   //}

   while(loop) /// LOADING SPELLS
   {
       getline(inFile, output);
       //cout << "phase: " << phase << "  " << output << endl << endl;
       if(output == "/END" || output == "/CYBERWARE")
       {
           break;
       }

       if(phase == 1)
       {
           nextSpellLevel = stringToInt(output);
           //spells.push_back(output);
       }
       if(phase == 2)
       {
           spells[nextSpellLevel].push_back(output);
           spellListSIMPLE.push_back(output);
       }
       if(phase == 3)
       {
           spellCosts[nextSpellLevel].push_back(stringToInt(output));
           pointsSpentOnSpells += stringToInt(output);
       }

       if(phase == 1 || phase == 2)
       {
           phase++;
       }
       else
       {
           phase = 1;
       }
   }

   phase = 1;

   cout << "FLAG 112" << endl;

   //augmentListSIMPLE.clear();

   //for(int i = 0; i < 13; i++)
   //{
       //augments[i].clear();
   //}

   while(loop) /// LOADING CYBERNETICS
   {
       getline(inFile, output);
       //cout << "phase: " << phase << "  " << output << endl << endl;
       if(output == "/END")
       {
           cout << "FLAG 111" << endl;
           break;
       }

       if(phase == 1)
       {
           nextSpellLevel = stringToInt(output);
           //spells.push_back(output);
       }
       if(phase == 2)
       {
           augments[nextSpellLevel].push_back(output);
           augmentListSIMPLE.push_back(output);
       }
       if(phase == 3)
       {
           augmentPointCosts[nextSpellLevel].push_back(stringToInt(output));
       }
       if(phase == 4)
       {
           augmentSpiritCosts[nextSpellLevel].push_back(stringToInt(output));
           cumulativeSpiritPenalty += stringToInt(output);
       }
       if(phase == 5)
       {
           if(output == "true" || output == "1")
           {
               augmentActive[nextSpellLevel].push_back(true);
           }
           else
           {
               augmentActive[nextSpellLevel].push_back(false);
           }
       }

       if(phase == 1 || phase == 2 || phase == 3 || phase == 4)
       {
           phase++;
       }
       else
       {
           phase = 1;
       }
   }

   ClearScreen();

   stats[6] = 50+totalSkillPoints / 20; /// Calculating initial spirit value. Real calculation happens in the add spell points function.

   return true;
};


