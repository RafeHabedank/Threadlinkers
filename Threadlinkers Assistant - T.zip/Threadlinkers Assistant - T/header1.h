//https://www.tutorialspoint.com/cprogramming/c_header_files.html
//https://stackoverflow.com/questions/17904643/error-with-multiple-definitions-of-function

#ifndef HEADER_FILE
#define HEADER_FILE

#define _WIN32_WINNT 0x0500

#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <math.h>
#include <vector>

#include <cstdlib> // Standard Library for C. Includes a lot of shit, including the random function
#include <ctime> // Time library for seeding the random number generator

#include <cwchar>

#define _WIN32_WINNT 0x0601


const int NUMBER_OF_COLORS = 6;


void ClearScreen();
void moveCursor(int posX, int posY);
int getKey();
int waitForKey();
bool keyPressed(int input);

std::string cutString(std::string source, int startPos, int endPos);
std::string simpleIntToString(int input);
int stringToInt(std::string input);
int getCost(std::string spellName, int spellLevel, bool playerColors[6], std::vector<std::string> knownSpells);

int randomNumber(int lowEnd, int highEnd);

void loadSpells();

class player
{
public:

    bool casterStart = false;

    std::string name;
    std::string race;
    int age;
    int totalSkillPoints;
    int spareSkillPoints;

    ///
    int pointsSpentOnSpells = 0;
    int pointsSpentOnCybernetics = 0;

    ///

    int sparePhysicalStatPoints = 0;
    int spareMentalStatPoints = 0;

    int spareStatPoints = 0;
    int maxHealth = 10;

    bool colors[6] = {false,false,false,false,false,false};
    std::vector<std::string> spells[10];
    std::vector<int> spellCosts[10];

    int spellSlots[10] = {3,1,0,0,0,0,0,0,0,0};
    int peakSlotLevel = 1;

    int updatePeakSpellLevel();

    std::vector<std::string> spellListSIMPLE; // A more simple list of all spells, unorganized, for supplement calculation in getCost()

    void loadData();
    void loadBackground(std::string backgroundName);

    void displayStats(int xPos, int yPos);
    bool addSpellPoints(int numberAdded);
    void displayKnownSpells(int xPos, int yPos);
    void updateFinalSkillTotals();

    int stats[7] = {0,0,0,0,0,0,0};
    std::string statNames[7] = {"Power","Speed","Dexterity","Intellectual","Perception","Eloquence","Spirit"};

    bool atCantripMax = true;

    bool notExceedingCantrips(int level);

    //int classAspect[64];

    //void loadClassAspects(std::string playerClass);

    std::vector<std::string> augments[12];
    std::vector<int> augmentPointCosts[12];
    std::vector<int> augmentSpiritCosts[12];

    std::vector<bool> augmentActive[12];

    std::vector<std::string> augmentListSIMPLE;
    std::vector<std::string> augmentMessageListSIMPLE;

    int cumulativeSpiritPenalty = 0;

    ///

    int skills[39] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int skillTotals[39] = {0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7};
};




class mouseClass
{
public:

    int x = 0;
    int y = 0;

    bool singleLeftClick;
    bool singleRightClick;

    bool holdingLeftClick;
    bool holdingRightClick;

    bool doubleClick;



    void update()
    {
        // Useful for solving the selecting window problem: https://stackoverflow.com/questions/46567248/how-to-disable-user-selection-in-windows-console

        HANDLE hStdin;
        DWORD fdwSaveOldMode;

        INPUT_RECORD irInBuf[128];

        DWORD cNumRead, fdwMode, i;

        hStdin = GetStdHandle(STD_INPUT_HANDLE);

        GetConsoleMode(hStdin, &fdwSaveOldMode);

        fdwMode = ENABLE_WINDOW_INPUT | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT | ENABLE_INSERT_MODE | ENABLE_EXTENDED_FLAGS;

        SetConsoleMode(hStdin, fdwMode);

        ReadConsoleInput(
            hStdin,      // input buffer handle
            irInBuf,     // buffer to read into
            128,         // size of read buffer
            &cNumRead); // number of records read


        for (i = 0; i < cNumRead; i++)
        {
            if(irInBuf[i].EventType == MOUSE_EVENT) // mouse input
            {
                x = irInBuf[i].Event.MouseEvent.dwMousePosition.X;
                y = irInBuf[i].Event.MouseEvent.dwMousePosition.Y;

                if(irInBuf[i].Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
                {
                    singleLeftClick = true;
                }
                else
                {
                    singleLeftClick = false;
                }

                if(irInBuf[i].Event.MouseEvent.dwButtonState == RIGHTMOST_BUTTON_PRESSED)
                {
                    singleRightClick = true;
                }
                else
                {
                    singleRightClick = false;
                }

                //if(irInBuf[i].Event.MenuEvent == MOUSE_WHEELED)
                //{
                    //while(true)
                    //{
                        //cout << "test";
                    //}
                //}
            }
            if(irInBuf[i].EventType == WM_MOUSEWHEEL)
            {
                while(true)
                {
                    std::cout << "mouse wheel";
                }
            }
        }
        fdwMode = ENABLE_ECHO_INPUT | ENABLE_INSERT_MODE | ENABLE_LINE_INPUT | ENABLE_MOUSE_INPUT | ENABLE_PROCESSED_INPUT; //| ENABLE_QUICK_EDIT_MODE;

        SetConsoleMode(hStdin, fdwMode);

        /// Some extra code to tell when the mouse buttons are being held down.
        if(GetAsyncKeyState(VK_LBUTTON)) //http://www.cplusplus.com/forum/windows/37822/
        {
            holdingLeftClick = true;
        }
        else
        {
            holdingLeftClick = false;
        }
        if(GetAsyncKeyState(VK_RBUTTON))
        {
            holdingRightClick = true;
        }
        else
        {
            holdingRightClick = false;
        }

    }

    void reset()
    {
        singleLeftClick = false;
        singleRightClick = false;
        holdingLeftClick = false;
        holdingRightClick = false;
    }
};

//void mouseClass::update()


#endif
