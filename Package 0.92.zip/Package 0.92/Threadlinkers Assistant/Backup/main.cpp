#include <iostream>
#include "header1.h"

using namespace std;

vector<string> spellNames[10];
vector<int> spellCosts[10];
vector<bool> spellAffs[10][6];

const int DESC_LINES = 35;
const int MENU_LIST_SIZE = 35;

vector<string> spellDesc[10][DESC_LINES];

vector<string> characterOptionsInMenu;

vector<bool> knownSpells[10];

player player1;


void characterOptions()
{
    ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Characters/001_character_names.txt");

    if(inFile.fail())
    {
        cout << "FAILED TO LOAD CHARACTER OPTIONS FILE" << endl;
    }
    else
    {
        cout << "LOADED CHARACTER OPTIONS FILE" << endl;
    }

    string fileOutput;

    while(true)
    {
        getline(inFile, fileOutput);
        if(fileOutput == "/END")
        {
            inFile.close();
            break;
        }
        else
        {
            characterOptionsInMenu.push_back(fileOutput);
        }
    }
};

void loadSpells()
{
    for(int i = 0; i < 4; i++)
    {
        spellNames[i].clear();
        ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/001_" + simpleIntToString(i) + "_names.txt");

        string output;

        cout << i << endl;
        if(inFile.fail())
        {
            cout << "File Failed to load" << endl;
        }

        while(true)
        {
            getline(inFile,output);
            if(output == "/END")
            {
                break;
            }
            spellNames[i].push_back(output);
            knownSpells[i].push_back(false);
        }
    }
};

void UpdateCosts(player player1)
{
    for(int i = 0; i < 9; i++)
    {
        spellCosts[i].clear();
        for(int x = 0; x < spellNames[i].size(); x++)
        {
            spellCosts[i].push_back(getCost(spellNames[i][x],i,player1.colors,player1.spellListSIMPLE));
        }
    }
}

void getAffinities()
{
    for(int i = 0; i < 9; i++)
    {
        for(int x = 0; x < 6; x++)
        {
            spellAffs[i][x].clear(); /// CLEARING OUT OLD DATA
        }
    }

    for(int i = 0; i < 9; i++)
    {
        for(int x = 0; x < spellNames[i].size(); x++)
        {
            string output;
            ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/" + spellNames[i][x] + ".txt");
            for(int y = 0; y < 5; y++) /// REMEMBER TO UPDATE THIS 5 IF THE SPACING CHANGES
            {
                getline(inFile, output); /// SKIPPING THE FIRST 5 LINES DUE TO FORMATTING
            }
            for(int y = 0; y < 6; y++)
            {
                getline(inFile, output);
                if(output[0] == '#')
                {
                    spellAffs[i][y].push_back(true);
                }
                else
                {
                    spellAffs[i][y].push_back(false);
                }
            }
        }
    }
}


void displaySpellInfo(int level, int index, bool lit)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    int attributeDistanceFromEdge = 32;
    int costDistanceFromEdge = 25;

    int spacer2Size = costDistanceFromEdge - spellNames[level][index].size();

        string spacer = "   ";
        string spacer2 = "";

    for(int i = 0; i < spacer2Size; i++)
    {
        spacer2 = spacer2 + " ";
    }

    SetConsoleTextAttribute( hStdOut, 0x0F);

    if(lit)
    {
        SetConsoleTextAttribute( hStdOut, 0xF0);
    }

    cout << spellNames[level][index];
    SetConsoleTextAttribute( hStdOut, 0x0F);
    cout << spacer2;


    cout << "("<< spellCosts[level][index] << ")";

    cout << spacer;

    /// WHITE
    if(spellAffs[level][0][index])
    {
        SetConsoleTextAttribute( hStdOut, 0xFF);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";


    /// BLACK
    if(spellAffs[level][1][index])
    {
        SetConsoleTextAttribute( hStdOut, 0x88);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// BLUE
    if(spellAffs[level][2][index])
    {
        SetConsoleTextAttribute( hStdOut, 0x99);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// GREEN
    if(spellAffs[level][3][index])
    {
        SetConsoleTextAttribute( hStdOut, 0xAA);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// RED
    if(spellAffs[level][4][index])
    {
        SetConsoleTextAttribute( hStdOut, 0xCC);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// BROWN
    if(spellAffs[level][5][index])
    {
        SetConsoleTextAttribute( hStdOut, 0x66);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    SetConsoleTextAttribute( hStdOut, 0x0F);

    if(knownSpells[level][index])
    {
        cout << "   Known";
    }
    else
    {
        cout << "         ";
    }
    //cout << "test";

    //cout << knownSpells[level][index];

    //cout << "Lev: " << level << " Ind: " << index;
}


void displayDesc(int x, int y, int level, int index)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );


    for(int i = 0; i < DESC_LINES; i++)
    {
        moveCursor(x,y+i);
        cout << "                                                                                   ";
        moveCursor(x,y+i);

        SetConsoleTextAttribute( hStdOut, 0x88); /// Displaying Left Sidebar
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";


        cout << spellDesc[level][i][index];
    }
}

void resizeConsole()
{
    HWND console = GetConsoleWindow();
    RECT r;
    GetWindowRect(console, &r); //stores the console's current dimensions

    //MoveWindow(window_handle, x, y, width, height, redraw_window);
    MoveWindow(console, r.left, r.top, 1500, 800, TRUE);
}

void loadSpellDescs()
{
    for(int i = 0; i < 10; i++) /// loop for the spell levels
    {
        for(int x = 0; x < spellNames[i].size(); x++) /// loop for each spell in a given level
        {
            /// Loading Spell Document
            ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/" + spellNames[i][x] + ".txt");

            /// defining a var for the output of lines
            string output;

            for(int y = 0; y < 12; y++) ///skipping 12 lines to get to the description section of the spell document
            {
                getline(inFile,output);
            }

            for(int y = 0; y < DESC_LINES; y++) ///expanding the vector and filling in blank values b/c the description might not be the full set of lines
            {
                spellDesc[i][y].push_back("");
            }

            for(int y = 0; y < DESC_LINES; y++) ///reading the description and transcribing the info into the proper var
            {
                getline(inFile,output);
                if(output == "/END") ///ending the transcription if the end of the document is reached
                {
                    break;
                }

                spellDesc[i][y][x] = output;
            }
        }
    }
}


void displayBuyMenuList(int selectedSpellIndex, int startingPosOfList, int level, int x, int y)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(x,y);

    int length = MENU_LIST_SIZE;
    int line = 0;

    bool lit = false;

    for(int i = startingPosOfList; i < spellNames[level].size() && i < (startingPosOfList + length); i++)
    {
        moveCursor(x,y + line);

        SetConsoleTextAttribute( hStdOut, 0x88); /// writing the left sidebar
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";

        if(i == selectedSpellIndex)
        {
            lit = true;
        }

        displaySpellInfo(level,i,lit);

        lit = false;
        line++;
    }
}


void ShowConsoleCursor(bool showFlag)
{
    //HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

    //CONSOLE_CURSOR_INFO     cursorInfo;

    //GetConsoleCursorInfo(out, &cursorInfo);
    //cursorInfo.bVisible = showFlag; // set the cursor visibility
    //cursorInfo.dwSize = 50;
    //SetConsoleCursorInfo(out, &cursorInfo);

    /* Remove the cursor (does not work in full screen) */

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_CURSOR_INFO CursoInfo;

    CursoInfo.dwSize = 1;         /* The size of caret */

    CursoInfo.bVisible = showFlag;   /* Caret is visible? */

    SetConsoleCursorInfo(hConsole, &CursoInfo);

}


void displayHeader(int levelSelected, player player1)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(25,0);

    string headerElements[11] = {"Character","Cantrips","Level 1","Level 2","Level 3","Level 4","Level 5","Level 6","Level 7","Level 8","Level 9"};
    for(int i = 0; i < 11; i++)
    {
        SetConsoleTextAttribute(hStdOut, 0x77);
        cout << "|";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";

        if(levelSelected == (i - 1))
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        cout << headerElements[i];
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";
    }

    //if(levelSelected != -1)
    //{
        moveCursor(83,3);

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);

        cout << " Spare Spell Points/Max Spell Points: " << player1.spareSkillPoints << "/" << player1.totalSkillPoints << " ";

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
    //}

}

void player::displayKnownSpells(int xPos, int yPos)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    int levelPositions[10];

    int linesWritten = 0;

    for(int i = 0; i < 10; i++)
    {
        levelPositions[i] = linesWritten;
        for(int x = 0; x < spells[i].size(); x++)
        {
            moveCursor(xPos,yPos + linesWritten);
            SetConsoleTextAttribute( hStdOut, 0x88);
            cout << "|";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " " << spells[i][x];
            linesWritten++;

            if(x == 0)
            {
                moveCursor(xPos + 20,yPos + linesWritten - 1);

                SetConsoleTextAttribute( hStdOut, 0x88);
                cout << "|";
                SetConsoleTextAttribute( hStdOut, 0x0F);

                if(i == 0)
                {
                    cout << " Max Cantrips: ";
                }
                if(i == 1)
                {
                     cout << " 1st Level Spell Slots: ";
                }
                cout << spellSlots[i];
            }
        }
        moveCursor(xPos,yPos + linesWritten);
        SetConsoleTextAttribute( hStdOut, 0x88);
        cout << "|";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        linesWritten++;
    }

    string lines[10] = {"Cantrips","1st Level","2nd Level","3rd Level","4th Level","5th Level","6th Level","7th Level","8th Level","9th Level"};

    for(int i = 0; i < 10; i++)
    {
        moveCursor(xPos - lines[i].size() - 1, yPos + levelPositions[i]);
        cout << lines[i];
    }
}


void player::displayStats(int xPos, int yPos)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    SetConsoleTextAttribute(hStdOut, 0x0F);

    //string catagories[10] = {"Total Spell Points","Spare Spell Points","Max Health",""};
    moveCursor(xPos - 7,yPos);

    cout << "Health ";

    SetConsoleTextAttribute(hStdOut, 0x88);
    cout << "X";

    SetConsoleTextAttribute(hStdOut, 0x0F);
    cout << " " << maxHealth;

    SetConsoleTextAttribute(hStdOut, 0x88);
    moveCursor(xPos,yPos+1);
    cout << "X";
    SetConsoleTextAttribute(hStdOut, 0x0F);


    moveCursor(xPos - 18,yPos + 2);
    cout << "Spare Stat Points ";

    SetConsoleTextAttribute(hStdOut, 0x88);
    cout << "X";
    SetConsoleTextAttribute(hStdOut, 0x0F);

    if(spareStatPoints != 0)
    {
        SetConsoleTextAttribute(hStdOut, 0x0B);
    }

    cout << " " << spareStatPoints;

    SetConsoleTextAttribute(hStdOut, 0x88);
    moveCursor(xPos,yPos+3);
    cout << "X";
    SetConsoleTextAttribute(hStdOut, 0x0F);

    for(int i = 0; i < 7; i++)
    {
        moveCursor(xPos - (statNames[i].size() + 1), yPos + 4 + i);
        cout << statNames[i] << " ";

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << " " << stats[i];
    }





}

void updateKnownSpellsInList(player player1)
{
    for(int i = 0; i < 10; i++)
    {
        for(int x = 0; x < spellNames[i].size(); x++)
        {
            for(int y = 0; y < player1.spellListSIMPLE.size(); y++)
            {
                if(spellNames[i][x] == player1.spellListSIMPLE[y])
                {
                    knownSpells[i][x] = true;
                }
            }
        }
    }
}


void saveCharacter(player player1)
{
    ofstream outFile("C:/001-Programs/testfile.txt");

    outFile << "Name:" << endl;
    outFile << player1.name << endl << endl;

    outFile << "Race:" << endl;
    outFile << player1.race << endl << endl;

    outFile << "Age:" << endl;
    outFile << player1.age << endl << endl;

    outFile << "Colors:" << endl;
    for(int i = 0; i < 6; i++)
    {
        if(player1.colors[i])
        {
            if(i == 0)
            {
                outFile << "White" << endl;
            }
            if(i == 1)
            {
                outFile << "Black" << endl;
            }
            if(i == 2)
            {
                outFile << "Blue" << endl;
            }
            if(i == 3)
            {
                outFile << "Green" << endl;
            }
            if(i == 4)
            {
                outFile << "Red" << endl;
            }
            if(i == 5)
            {
                outFile << "Brown" << endl;
            }
        }
    }
    outFile << endl;

    outFile << "Total Skill Points:" << endl;
    outFile << player1.totalSkillPoints << endl << endl;

    outFile << "Spare Skill Points:" << endl;
    outFile << player1.spareSkillPoints << endl << endl;

    outFile << "Health Points:" << endl;
    outFile << player1.maxHealth << endl << endl;

    outFile << "Spells Known:" << endl;
    outFile << "=============" << endl;

    for(int i = 0; i < 10; i++)
    {
        for(int x = 0; x < player1.spells[i].size(); x++)
        {
            outFile << i << endl;
            outFile << player1.spells[i][x] << endl;
            outFile << player1.spellCosts[i][x] << endl;
        }
    }

    outFile << "/END";

    outFile.close();
}


bool confirmPurchase(player player1, string name)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(5,3);

    SetConsoleTextAttribute( hStdOut, 0xCC);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);

    cout << " Are you sure you want to learn " << name << "? ";

    SetConsoleTextAttribute( hStdOut, 0xCC);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);

    while(true)
    {
        int key = waitForKey();
        if(key == 89)
        {
            moveCursor(5,3);
            cout << "                                                             ";
            return true;
        }
        if(key == 78)
        {
            moveCursor(5,3);
            cout << "                                                             ";
            return false;
        }
    }



    //

}


bool player::addSpellPoints(int numberAdded) /// Updates spell slots and stat points according to the amount of spell points added
{
    int previousTotal = totalSkillPoints;

    totalSkillPoints += numberAdded;
    spareSkillPoints += numberAdded;

    int num1 = previousTotal / 20;
    int num2 = totalSkillPoints / 20;


    spareStatPoints = spareStatPoints + (num2 - num1);

    /// SPELL SLOTS
    /// Spell points are called skill points, thats just the way the variable worked out

    if(totalSkillPoints >= 100)
    {
        spellSlots[1] = 2;
    }
    if(totalSkillPoints >= 200)
    {
        spellSlots[1] = 3;
        spellSlots[2] = 1;
    }
    if(totalSkillPoints >= 300)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 2;
    }
    if(totalSkillPoints >= 400)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 3;
        spellSlots[3] = 1;
    }
    if(totalSkillPoints >= 500)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 3;
        spellSlots[3] = 2;
    }
    if(totalSkillPoints >= 500)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 3;
        spellSlots[3] = 3;
    }
}

int main()
{

    player player1;
    player1.name = "Drake";
    player1.loadData();

    //////////////////////////////////////////////////////////////////

    SetConsoleTitleA("Threadlinkers Digital Character Assistant");

    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    CONSOLE_CURSOR_INFO cursorInfo;

    bool showFlag = true;

    GetConsoleCursorInfo(hStdOut, &cursorInfo);
    cursorInfo.bVisible = showFlag; // set the cursor visibility
    SetConsoleCursorInfo(hStdOut, &cursorInfo);

    ShowConsoleCursor(false);
    //SetConsoleTextAttribute( hStdOut, 0x01); //darkBlue
    //SetConsoleTextAttribute( hStdOut, 0x02); //med-dark green
    //SetConsoleTextAttribute( hStdOut, 0x03); //turquoise
    //SetConsoleTextAttribute( hStdOut, 0x04); // darkRed
    //SetConsoleTextAttribute( hStdOut, 0x05); // Purple
    //SetConsoleTextAttribute( hStdOut, 0x06); // Dingy yellow
    //SetConsoleTextAttribute( hStdOut, 0x07); // very light gray
    //SetConsoleTextAttribute( hStdOut, 0x08); // Dark gray
    //SetConsoleTextAttribute( hStdOut, 0x09); // Blue
    //SetConsoleTextAttribute( hStdOut, 0x0A); //light green
    //SetConsoleTextAttribute( hStdOut, 0x0B); //light blue
    //SetConsoleTextAttribute( hStdOut, 0x0C); //Red
    //SetConsoleTextAttribute( hStdOut, 0x0D); // purple pink
    //SetConsoleTextAttribute( hStdOut, 0x0E); // yellow
    //SetConsoleTextAttribute( hStdOut, 0x0F); // white

    //SetConsoleTextAttribute(hStdOut,0xE1);

menu: /// MENU MENU MENU

    ClearScreen();
    moveCursor(0,0);

    resizeConsole();

    ShowConsoleCursor(false);

    ifstream inFile("title_art.txt");
    if(inFile.fail())
    {
        cout << "Failed to load file: title_art.txt" << endl;
    }
    string output;

    for(int i = 0; i < 13; i++)
    {
        getline(inFile,output);
        cout << output << endl;
    }

    SetConsoleTextAttribute( hStdOut, 0xFF);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x88);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x99);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0xAA);
    cout << "XXXXXXXXXXX      XXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0xCC);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x66);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x0F);

    inFile.close();

    bool menuLoop = true;
    bool flipFlop;

    //Sleep (3000);

    int menuOption = 0;

    int OPTIONS_HORO = 76;
    int OPTIONS_VERT = 20;

    while(menuLoop)
    {
        /// OPTION 0
        moveCursor(OPTIONS_HORO,OPTIONS_VERT);
        if(menuOption == 0)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
            cout << "New Character";
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        else
        {
            cout << "New Character";
        }

        /// OPTION 1
        moveCursor(OPTIONS_HORO,OPTIONS_VERT + 1);
        if(menuOption == 1)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
            cout << "Load Character";
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        else
        {
            cout << "Load Character";
        }

        /// OPTION 2
        moveCursor(OPTIONS_HORO,OPTIONS_VERT + 2);
        if(menuOption == 2)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
            cout << "UTILITIES";
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        else
        {
            cout << "UTILITIES";
        }

        /// OPTION 3
        moveCursor(OPTIONS_HORO,OPTIONS_VERT + 3);
        if(menuOption == 3)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
            cout << "DEBUG";
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        else
        {
            cout << "DEBUG";
        }



        if(keyPressed(83))
        {
            menuOption++;
            if(menuOption == 4) /// NUMBER OF MENU OPTIONS
            {
                menuOption = 2;
            }
        }

        if(keyPressed(87))
        {
            menuOption--;
            if(menuOption == -1)
            {
                menuOption = 0;
            }
        }

        if(keyPressed(13) && menuOption == 1)
        {
            goto loadCharacter;
        }
        if(keyPressed(13) && menuOption == 3) /// DEBUG MENU OPTION
        {
            //goto debug;
        }
        Sleep (50);
    }

loadCharacter: /// LOAD CHARACTER LOAD CHARACTER LOAD CHARACTER

    ClearScreen();
    characterOptions();

    if(characterOptionsInMenu.size() == 0)
    {
        goto menu;
    }

    //cout << "Character 1: " << characterOptionsInMenu[0] << endl;
    Sleep(50);
    ClearScreen();

    menuOption = 0;

    while(true)
    {
        for(int i = 0; i < characterOptionsInMenu.size(); i++)
        {
            SetConsoleTextAttribute( hStdOut, 0x0F);
            if(i == menuOption)
            {
                SetConsoleTextAttribute( hStdOut, 0xF0);
            }

            moveCursor(80,10+i);
            cout << characterOptionsInMenu[i];
        }

        if(keyPressed(83))
        {
            menuOption++;
            if(menuOption == characterOptionsInMenu.size())
            {
                menuOption = characterOptionsInMenu.size() -1;
            }
        }

        if(keyPressed(87))
        {
            menuOption--;
            if(menuOption == -1)
            {
                menuOption = 0;
            }
        }

        if(keyPressed(13))
        {
            player1.name = characterOptionsInMenu[menuOption];
            player1.loadData();
            SetConsoleTextAttribute( hStdOut, 0x0F);
            goto playerMenu;
            //goto loadCharacter;
            /// PLACE LOADING ROUTINES HERE
        }

        if(keyPressed(16))
        {
            goto menu;
        }

        Sleep(100);
        //ClearScreen();
    }

    goto menu;

playerMenu:

    //ClearScreen();
    //moveCursor(0,0);
    //cout << "Name: " << player1.name << endl;
    //cout << "Age: " << player1.age << endl;
    //cout << "Race: " << player1.race << endl;

    //cout << "White: " << player1.colors[0] << endl;
    //cout << "Black: " << player1.colors[1] << endl;
    //cout << "Blue: " << player1.colors[2] << endl;
    //cout << "green: " << player1.colors[3] << endl;
    //cout << "red: " << player1.colors[4] << endl;
    //cout << "Brown: " << player1.colors[5] << endl;

    //cout << "Cost ofxx Example: " << getCost("example", 1, player1.colors, player1.spellListSIMPLE) << endl;

    loadSpells();

    //cout << "Name of 1,0: " << spellNames[1][0] << endl;
    //cout << "cost of 1,0: " << spellCosts[1][0] << endl;
    UpdateCosts(player1);
    getAffinities();
    loadSpellDescs();
    updateKnownSpellsInList(player1);

playerMenuLater:
    //cout << "SIZE: " << player1.spellListSIMPLE.size();

    //while(true)
    //{

    //}

    //cout << "Cost of Examplex2: " << getCost("Burning Hands",1,player1.colors,player1.spellListSIMPLE) << endl;

    //cout << "Size: " << spellNames[0].size() << endl;
    //cout << spellNames[1][0] << " costs " << spellCosts[1][0] << endl << endl;

    //for(int i = 0; i < player1.spellListSIMPLE.size(); i++)
    //{
        //cout << player1.spellListSIMPLE[i] << endl;
    //}

    //cout << spellNames[1][2] << " costs " << spellCosts[1][2] << endl;

    //displaySpellInfo(1,1);
    //displaySpellInfo(1,0);
    //displaySpellInfo(1,2);

    ///for(int i = 0; i < spellNames[1].size(); i++)
    ///{
        ///displaySpellInfo(1,i,true);
        ///cout << endl;
    ///}

    //cout << spellNames[1][15] << endl << endl;
    //for(int i = 0; i < 25; i++)
    //{
        //cout << spellDesc[1][i][15] << endl;
    //}

    //ClearScreen();
    //displayDesc(85,10,1,10);

    moveCursor(0,0);
    ClearScreen();

    int level = 0;
    int selectorPos = 0;
    int listStartPos = 0;

    SetConsoleTextAttribute( hStdOut, 0x0F);
    displayBuyMenuList(selectorPos,listStartPos,level,5,5);

    displayDesc(83,5,level,selectorPos);

    //83,87 ,   13

    //cout << "| A << | Character | Cantrips | Level 1 | Level 2 | Level 3 | Level 4 | Level 5 | Level 6 | Level 7 | Level 8 | Level 9 | >> D |";

    while(true) /// SPELL MENU LOOP
    {
        moveCursor(0,0);
        displayHeader(level, player1);
        int key = waitForKey();
        //moveCursor(0,40);
        //cout << key;
        //Sleep(500);

        if(keyPressed(13) && !knownSpells[level][selectorPos] && spellCosts[level][selectorPos] <= player1.spareSkillPoints && confirmPurchase(player1,spellNames[level][selectorPos]) && player1.spellSlots[level] != 0)
        {
            player1.spells[level].push_back(spellNames[level][selectorPos]);
            player1.spellListSIMPLE.push_back(spellNames[level][selectorPos]);
            player1.spellCosts[level].push_back(spellCosts[level][selectorPos]);

            player1.spareSkillPoints -= spellCosts[level][selectorPos];

            UpdateCosts(player1);
            updateKnownSpellsInList(player1);
        }



        if(key == 83 && selectorPos < spellNames[level].size() - 1)
        {
            selectorPos++;
        }
        if(key == 87 && selectorPos > 0)
        {
            selectorPos--;
        }
        if(key == 68)
        {
            level++;
            if(level > 9)
            {
                level = 9;
            }

            if(listStartPos + MENU_LIST_SIZE > spellNames[level].size())
            {
                listStartPos = spellNames[level].size() - MENU_LIST_SIZE;
            }
            if(selectorPos >= spellNames[level].size())
            {
                selectorPos = spellNames[level].size() - 1;
            }
        }
        if(key == 65)
        {
            level--;

            if(level < 0)
            {

                goto playerStatPage;
                level = 0;
            }

            if(listStartPos + MENU_LIST_SIZE > spellNames[level].size())
            {
                listStartPos = spellNames[level].size() - MENU_LIST_SIZE;
            }
            if(selectorPos >= spellNames[level].size())
            {
                selectorPos = spellNames[level].size() - 1;
            }
        }

        if(selectorPos == listStartPos + MENU_LIST_SIZE)
        {
            listStartPos++;
        }
        if(selectorPos == listStartPos -1)
        {
            listStartPos--;
        }

        SetConsoleTextAttribute( hStdOut, 0x0F);
        displayBuyMenuList(selectorPos,listStartPos,level,5,5);

        displayDesc(83,5,level,selectorPos);


        SetConsoleTextAttribute( hStdOut, 0x00);
        //Sleep(30);
    }

playerStatPage:

    ClearScreen();
    moveCursor(0,0);
    displayHeader(level,player1);

    moveCursor(0,2);

    player1.addSpellPoints(0); /// Updates spell slots


    player1.displayKnownSpells(12,5); /// make sure to update other if moved

    saveCharacter(player1);

//debug:
    //cout << "DEBUG";
    //cout << "SIZE: " << player1.spellListSIMPLE.size();

    menuOption = 0;
    int numberOfMenuItems = 2;

    while(true)
    {
statPageLoop:
        /// FIRST MENU OPTION
        moveCursor(83,17);
        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << " ";
        if(menuOption == 0)
        {
            SetConsoleTextAttribute(hStdOut, 0xf0);

        }
        cout << "Add Spell Points";

        if(menuOption == 0 && keyPressed(13))
        {
            SetConsoleTextAttribute(hStdOut, 0x0F);
            cout << " Input Quantity To Add: ";
            ShowConsoleCursor(true);

            cin.clear();

            FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE)); /// VERY IMPORTANT https://stackoverflow.com/questions/8468514/getasynckeystate-creating-problems-with-cin?rq=1
            //https://stackoverflow.com/questions/257091/how-do-i-flush-the-cin-buffer

            string numberInput = "";

            Sleep(500);
            cin >> numberInput;
            ShowConsoleCursor(false);
            moveCursor(101,17);
            cout << "                                 ";
            Sleep(200);



            int spellPointsAdded = stringToInt(numberInput);
            //player1.totalSkillPoints += spellPointsAdded;
            //player1.spareSkillPoints += spellPointsAdded;
            player1.addSpellPoints(spellPointsAdded);

            player1.displayKnownSpells(12,5); /// Make sure to update other if moved
        }

        player1.addSpellPoints(0); /// Updates spell slots


        /// SECOND MENU OPTION
        moveCursor(83,18);
        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << " ";
        if(menuOption == 1)
        {
            SetConsoleTextAttribute(hStdOut, 0xf0);

        }
        cout << "Apply Stat Points";

        SetConsoleTextAttribute(hStdOut, 0x0F);

        int subMenuOption = 0;
forgiveMe: /// Don't ask, it hitches if i don't reset the loop like this, not sure why, and I don't care enough at this point
           /// The loop in question is the stat add loop, and it has problems when you confirm, the check for the enter
           /// key (button 13) always passes after passing once, even if the button is no longer held
        if(menuOption == 1 && keyPressed(13))
        {

            Sleep(250);
            while(true)
            {
                for(int i = 0; i < 6; i++)
                {
                    if(subMenuOption == i)
                    {
                        SetConsoleTextAttribute(hStdOut, 0xF0);
                    }

                    moveCursor(90,9+i);
                    cout << "+";
                    SetConsoleTextAttribute(hStdOut, 0x0F);
                }
                if(keyPressed(83))
                {
                    subMenuOption++;
                    if(subMenuOption == 6)
                    {
                        subMenuOption--;
                    }
                }

                if(keyPressed(87))
                {
                    subMenuOption--;
                    if(subMenuOption == -1)
                    {
                        subMenuOption = 0;
                    }
                }

                if(keyPressed(16))
                {
                    SetConsoleTextAttribute(hStdOut, 0x0F);
                    for(int i = 0; i < 6; i++)
                    {
                        moveCursor(90,9+i);
                        cout << "   ";
                    }
                    goto statPageLoop;
                }

                if(keyPressed(13) && player1.spareStatPoints > 0)
                {
                    moveCursor(92,9+subMenuOption);
                    cout << "How many points would you like to assign? ";
                    string input;
                    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
                    cin >> input;

                    if(stringToInt(input) <= player1.spareStatPoints)
                    {
                        player1.stats[subMenuOption] += stringToInt(input);
                        player1.spareStatPoints -= stringToInt(input);
                    }

                    moveCursor(92,9+subMenuOption);
                    cout << "                                            ";
                    player1.displayStats(83,5); /// XXXXXXXXXXXXXXXXX
                    saveCharacter(player1);
                    goto forgiveMe;
                }

                Sleep(60);
            }
        }

/// ================================================================

        if(keyPressed(83))
        {
            menuOption++;
            if(menuOption == numberOfMenuItems)
            {
                menuOption--;
            }
        }

        if(keyPressed(87))
        {
            menuOption--;
            if(menuOption == -1)
            {
                menuOption = 0;
            }
        }

        moveCursor(0,0);
        displayHeader(level,player1);
        player1.displayStats(83,5); /// make sure to update other occurance if changed (see above for X's)
        int key = waitForKey();

        SetConsoleTextAttribute(hStdOut, 0x0F);
        //moveCursor(50,10);
        //cout << key;

        if(key == 68)
        {
            level = 0;
            goto playerMenuLater;
        }
    }

    return 0;
}
