#include <iostream>
#include "header1.h"

using namespace std;


vector<string> spellNames[10];
vector<int> spellCosts[10];
vector<bool> spellAffs[10][6];

const int DESC_LINES = 105;
const int MENU_LIST_SIZE = 35;

vector<string> spellDesc[10][DESC_LINES];

vector<string> characterOptionsInMenu;

vector<bool> knownSpells[10];

player player1;
bool hasCharacteristicCantrips = false;
bool hasCharacteristicSpells = false;

int CONSOLE_WIDTH = 1400;
int CONSOLE_HEIGHT = 800;

mouseClass mouse;



vector<string> perkNames[10];
vector<int> perkCosts[10];

vector<string> basePerkAspects;
vector<int> classAspects;

///vector<vector<int>> perkAspects[10]; /// 0 = neither add nor subtract, 1 = add, 2 = subtract

vector<string> augmentNames[12];
vector<int> augmentPointCosts[12];
vector<int> augmentSpiritCosts[12];
vector<int> augmentSpiritCostsLowerBound[12];
vector<int> augmentSpiritCostsUpperBound[12];

vector<string> augmentMessages[12];

vector<string> augmentDesc[12][DESC_LINES];

const int TEXT_SPEED = 20;


const int SIZE_OF_SKILL_NAMES = 39;

std::string GEN_SKILLS_NAMES[SIZE_OF_SKILL_NAMES] = {
    "Climbing",
    "Swimming",
    "Parkour",
    "Archery",
    "Blades",
    "Bludgeons",
    "Driving",
    "Heavy Weapons",
    "Light Step",
    "Martial Arts",
    "One-Handed Guns",
    "Pilot",
    "Sleight of Hand",
    "Throwing",
    "Two-Handed Guns",
    "Accounting",
    "Arcana",
    "Electronics",
    "Explosives",
    "Hacking",
    "Heavy Machinery",
    "History",
    "Mechanics",
    "Medical",
    "Physics",
    "Survival",
    "Wet Science",
    "Animal Handling",
    "Lip Reading",
    "Read Body Language",
    "Bargain",
    "Fast Talk",
    "Intimidate",
    "Performance",
    "Personal Style",
    "Rhetoric",
    "Storytelling",
    "Soft Magic",
    "Stealth Casting"
};

const int SKILL_LIST_HEADER_POSITIONS[8] = {0,2,3,15,27,30,37,SIZE_OF_SKILL_NAMES};
const std::string NAMES_OF_STATS[7] = {"Power","Speed","Dexterity","Intellectual","Perception","Eloquence","Spirit"};

bool magicMenu = true;

//mouse.update();

vector<string> categoryNames;

const int ROLL_HISTORY_SIZE = 8;

int rollValues[ROLL_HISTORY_SIZE][16] = {{-500},{-500},{-500},{-500},{-500},{-500},{-500},{-500}};
string rollSkillNames[ROLL_HISTORY_SIZE] = {"","","","","","","",""};


void displayRecoilHeader(int xPos, int yPos, int selectedPosition)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(xPos - 7, yPos);
    cout << "Name ";
    SetConsoleTextAttribute( hStdOut, 0x88);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);




    moveCursor(xPos - 13,yPos + 1);
    cout << "Base Skill ";
    SetConsoleTextAttribute( hStdOut, 0x88);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);


    moveCursor(xPos - 10,yPos + 2);
    cout << "Penalty ";
    SetConsoleTextAttribute( hStdOut, 0x88);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);


    moveCursor(xPos - 11,yPos + 3);
    cout << "Attempts ";
    SetConsoleTextAttribute( hStdOut, 0x88);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);
    //cout <<

    for(int i = 1; i <= 6; i++)
    {
        cout << " ";

        if(i == selectedPosition)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        cout << "[" << i << "]";
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }

}

void initializeRollValues()
{
    for(int i = 0; i < ROLL_HISTORY_SIZE; i++)
    {
        for(int x = 0; x < 16; x++)
        {
            rollValues[i][x] = -500;
        }
    }

    //rollValues[0][0] = 1;
    //rollValues[0][1] = 2;
    //rollValues[0][2] = 3;
    //rollValues[0][3] = 4;
}

int roll(int maxValue)
{
    return randomNumber(1, maxValue);
}

void player::rollPips()
{
    for(int i = 0; i < SIZE_OF_SKILL_NAMES; i++)
    {
        if(skillPips[i] == 2)
        {
            if(spareSkillPoints >= 10)
            {
                spareSkillPoints -= 10;

                if(skills[i] < 20 && skills[i] > 9)
                {
                    skills[i] += 2;
                }
                else if(skills[i] < 10)
                {
                    skills[i] += 3;
                }
                else
                {
                    skills[i]++;
                }
                skillPips[i] = 0;
            }
            else
            {
                skillPips[i] = 1;
            }
        }

        if(skillPips[i] == 1)
        {
            if(randomNumber(0,1))
            {
                if(skills[i] < 20 && skills[i] > 9)
                {
                    skills[i] += 2;
                }
                else if(skills[i] < 10)
                {
                    skills[i] += 3;
                }
                else
                {
                    skills[i]++;
                }
            }
            skillPips[i] = 0;
        }
    }
}

void rollRecoilAndUpdateHistory(player player1, int index, int numberOfStrikes, int rollType)
{
    int statMod = player1.skillTotals[player1.recoilSkill[index]] - (player1.recoilAmount[index] * (numberOfStrikes - 1));

    //moveCursor(0,1);
    //cout << "     ";
    //moveCursor(0,1);
    //cout << player1.skillTotals[player1.recoilSkill[index]];

    int result1[16] = {-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500};
    int result2[16] = {-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500,-500};

    for(int i = 0; i < numberOfStrikes; i++)
    {
        result1[i] = roll(100) + statMod;
        result2[i] = roll(100) + statMod;
    }

    /// ROLL TYPES
    /// 0 = disadvantage
    /// 1 = normal
    /// 2 = advantage

    if(rollType == 0)
    {
        for(int i = 0; i < 16; i++)
        {
            if(result1[i] > result2[i])
            {
                result1[i] = result2[i];
            }
        }
    }

    if(rollType == 2)
    {
        for(int i = 0; i < 16; i++)
        {
            if(result1[i] < result2[i])
            {
                result1[i] = result2[i];
            }
        }
    }

    for(int i = ROLL_HISTORY_SIZE - 1; i >= 0; i--)
    {
        if(i != 0)
        {
            for(int x = 0; x < 16; x++)
            {
                rollValues[i][x] = rollValues[i-1][x];
            }
            rollSkillNames[i] = rollSkillNames[i-1];
        }
        else
        {
            for(int x = 0; x < 16; x++) /// Clearing the dataslot, to only fill in one value
            {
                rollValues[0][x] = result1[x];
            }
            //rollValues[0][0] = result1[0];
            rollSkillNames[0] = player1.recoilName[index];
        }
    }
}

void player::updateRealStats()
{
    for(int i = 0; i < 7; i++)
    {
        realStats[i] = stats[i];
        for(int x = 0; x < 7; x++)
        {
            if(statModActive[i][x] == 1)
            {
                realStats[i] += statModQuant[i][x];
            }
            if(statModActive[i][x] == 2)
            {
                realStats[i] -= statModQuant[i][x];
            }
        }
    }
}

void updateRollHistory(int rollValue, string thingRolled)
{
    //for(int i = ROLL_HISTORY_SIZE - 1; i >= 0; i--)
    //{
        //if(i != 0)
        //{
            //rollValues[i][0] = rollValues[i-1][0];
            //rollSkillNames[i] = rollSkillNames[i-1];
       //}
        //else
        //{
            //for(int x = 0; x < 16; x++)
            //{
                //rollValues[0][x] = -500;
            //}
            //rollValues[0][0] = rollValue;
            //rollSkillNames[0] = thingRolled;
        //}
    //}

    for(int i = ROLL_HISTORY_SIZE - 1; i >= 0; i--)
    {
        if(i != 0)
        {
            for(int x = 0; x < 16; x++)
            {
                rollValues[i][x] = rollValues[i-1][x];
            }
            rollSkillNames[i] = rollSkillNames[i-1];
        }
        else
        {
            for(int x = 0; x < 16; x++) /// Clearing the data slot, to only fill in one value
            {
                rollValues[0][x] = -500;
            }
            rollValues[0][0] = rollValue;
            rollSkillNames[0] = thingRolled;
        }
    }
}

void modifySettings(int widthMod, int heightMod)
{
    ifstream inFile("settings.txt");
    int width;
    int height;
    ///The first number is the width of the console and the second, the height.
    string output = "";
    getline(inFile, output);
    width = stringToInt(output);
    getline(inFile, output);
    height = stringToInt(output);

    width += widthMod;
    height += heightMod;

    inFile.close();

    ofstream outFile("settings.txt");
    outFile << width << endl << height << endl << "The first number is the width of the console and the second, the height.";
}

void player::updateFinalSkillTotals()
{
    for(int i = 0; i < 7; i++)
    {
        for(int x = SKILL_LIST_HEADER_POSITIONS[i]; x < SKILL_LIST_HEADER_POSITIONS[i+1]; x++)
        {
            skillTotals[x] = skills[x] + realStats[i];
        }
    }
}

void loadAugments()
{
    ifstream inFileNames("../Threadlinkers Assistant/Cyberware/001_aug_categories.txt");

    if(inFileNames.fail())
    {
        cout << "failed to load augment categories file" << endl;
    }

    string output = "";


    categoryNames.clear();

    while(true)
    {
        getline(inFileNames,output);
        if(output != "/END")
        {
            categoryNames.push_back(output);
        }
        else
        {
            break;
        }
    }

    inFileNames.close();

    for(int i = 0; i < categoryNames.size(); i++)
    {
        ifstream inFileNames("../Threadlinkers Assistant/Cyberware/" + categoryNames[i] + "/001_" + simpleIntToString(i) + "_names.txt");

        if(inFileNames.fail())
        {
            cout << "Failed to load: " << categoryNames[i] << ".txt" << endl;

        }

        while(true)
        {
            getline(inFileNames,output);
            if(output != "/END")
            {
                augmentNames[i].push_back(output);
            }
            else
            {
                break;
            }
        }

        for(int x = 0; x < augmentNames[i].size(); x++)
        {
            ifstream inFile("../Threadlinkers Assistant/Cyberware/" + categoryNames[i] + "/" + augmentNames[i][x] + ".txt");

            getline(inFile,output);
            getline(inFile,output);

            augmentPointCosts[i].push_back(stringToInt(output));

            getline(inFile,output);
            getline(inFile,output);
            getline(inFile,output);

            getline(inFile,output); /// Spacing to skip the unimplented supplement feature
            getline(inFile,output);

            getline(inFile,output); /// Spacing to skip the unimplented message/tag feature

            augmentMessages[i].push_back(cutString(output,7,output.size()));

            getline(inFile,output);

            int lowerBound = stringToInt(output);
            augmentSpiritCostsLowerBound[i].push_back(lowerBound);

            getline(inFile,output);
            getline(inFile,output);
            getline(inFile,output);

            int upperBound = stringToInt(output);
            augmentSpiritCostsUpperBound[i].push_back(upperBound);

            augmentSpiritCosts[i].push_back(randomNumber(lowerBound,upperBound));
        }
    }
}


void displayAugmentDesc(int x, int y, int level, int index, int page)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(0,0);

    if(page == 1)
    {
        for(int i = 0; i < 35; i++)
        {
            moveCursor(x,y+i);
            cout << "                                                                                   ";
            moveCursor(x,y+i);

            SetConsoleTextAttribute( hStdOut, 0x88); /// Displaying Left Sidebar
            cout << "X";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " ";
            cout << augmentDesc[level][i][index];
        }
    }

    if(page == 2)
    {
        for(int i = 35; i < 70; i++)
        {
            moveCursor(x,y+i-35);
            cout << "                                                                                   ";
            moveCursor(x,y+i-35);

            SetConsoleTextAttribute( hStdOut, 0x88); /// Displaying Left Sidebar
            cout << "X";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " ";
            cout << augmentDesc[level][i][index];
        }
    }

    if(page == 3)
    {
        for(int i = 70; i < 105; i++)
        {
            moveCursor(x,y+i-70);
            cout << "                                                                                   ";
            moveCursor(x,y+i-70);

            SetConsoleTextAttribute( hStdOut, 0x88); /// Displaying Left Sidebar
            cout << "X";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " ";
            cout << augmentDesc[level][i][index];
        }
    }
}

void displayAugmentSidebar(int selection)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );


    for(int i = 0; i < MENU_LIST_SIZE; i++)
    {
        SetConsoleTextAttribute( hStdOut, 0x88); // very light gray

        moveCursor(16,5+i);
        cout << "X";
    }

    for(int i = 0; i < categoryNames.size(); i++)
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
        moveCursor(1,5+3*i);

        if(i == selection)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        cout << cutString(categoryNames[i],4,20);
    }

    SetConsoleTextAttribute( hStdOut, 0x0F);
}


void loadAugmentDescs()
{
    for(int i = 0; i < 12; i++) /// loop for the augment types
    {
        for(int x = 0; x < augmentNames[i].size(); x++) /// loop for each augment for a given type
        {
            /// Loading Augment Document
            //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/" + spellNames[i][x] + ".txt");

            ifstream inFile("../Threadlinkers Assistant/Cyberware/" + categoryNames[i] + "/" + augmentNames[i][x] + ".txt");

            if(inFile.fail())
            {
                while(true)
                {
                    cout << i << " " << x << " " << categoryNames[i] << "/" << endl;
                }
            }
            //}
            /// defining a var for the output of lines
            string output;

            for(int y = 0; y < 16; y++) ///skipping 16 lines, to get to the description section of the spell document.
            {
                getline(inFile,output);
            }

            for(int y = 0; y < DESC_LINES; y++) ///expanding the vector and filling in blank values b/c the description might not be the full set of lines
            {
                augmentDesc[i][y].push_back("");
            }

            for(int y = 0; y < DESC_LINES; y++) ///reading the description and transcribing the info into the proper var
            {
                getline(inFile,output);
                if(output == "/END") ///ending the transcription if the end of the document is reached
                {
                    break;
                }

                augmentDesc[i][y][x] = output;
            }

        }
    }
}


void displayAugmentInfo(int type, int index, int x, int y, int selection, player player1)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    SetConsoleTextAttribute( hStdOut, 0x0F);

    moveCursor(x,y);

    cout << "                                                                 ";

    if(selection == index)
    {
        SetConsoleTextAttribute( hStdOut, 0xF0);
    }

    moveCursor(x,y);

    cout << augmentNames[type][index];

    moveCursor(x+24,y);

    SetConsoleTextAttribute( hStdOut, 0x0F);

    cout << "(" << augmentPointCosts[type][index] << ")";

    for(int i = augmentSpiritCostsLowerBound[type][index]; i <= augmentSpiritCostsUpperBound[type][index]; i ++)
    {
        SetConsoleTextAttribute( hStdOut, 0x44);
        moveCursor(x+29+(3*i),y);
        cout << "XX";
    }
    SetConsoleTextAttribute( hStdOut, 0x0F);

    for(int i = 0; i < player1.augmentListSIMPLE.size(); i++)
    {
        if(player1.augmentListSIMPLE[i] == augmentNames[type][index])
        {
            moveCursor(x + 59,y);
            cout << "known";
        }
    }

}

int getPerkCost(string perkName, int perkLevel, bool playerColors[6], vector<string> knownSpells)
{
    string level = simpleIntToString(perkLevel);

    string output;

    //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + level + "/" + spellName + ".txt"); /// MAKE SURE TO UPDATE NAME
    ifstream inFile("../Threadlinkers Assistant/Abilities/" + level + "/" + perkName + ".txt");
    getline(inFile,output);
    getline(inFile,output);

    int stringSize = output.size();

    string initialCost = "";

    for(int i = 0; i < stringSize; i++)
    {
        if(output[i] == ':')
        {
            i += 2;
            for(; i < stringSize; i++)
            {
                initialCost += output[i];
            }
        }
    }
    int cost = stringToInt(initialCost);

    /// =========================================================================

    getline(inFile,output);
    stringSize = output.size();

    for(int i = 0; i < stringSize; i++)
    {
        //cout << i << endl;
        if(output[i] == ',')
        {
            i += 2;
            int startPos = i;
            int endPos = 0;
            bool loop = true;
            while(loop)
            {
                if(output[i] == '(')
                {
                    endPos = i - 2;
                    //i--;
                    loop = false;
                }
                i++;
            }
            string suppName = "";
            suppName = cutString(output,startPos,endPos);
            //cout << "detected name of: " << suppName << '/' << endl;

            int numStart;
            int numEnd;

            //cout << knownSpells.size() << endl;

            for(int x = 0; x < knownSpells.size(); x++)
            {
                //cout << "known spell " << x << ": " << knownSpells[x] << "/" << endl;
                if(knownSpells[x] == suppName)
                {
                    //cout << "Applied supplements: " << suppName << " spell number " << x << endl;
                    i = endPos + 3; /// FIX THIS FIX THIS FIX THIS FIX THIS
                    numStart = i;
                    bool loop2 = true;
                    while(loop2)
                    {
                        if(output[i] == ')')
                        {
                            numEnd = i - 1;
                            loop2 = false;
                            break;
                        }
                        i++;
                    }
                    string numString = cutString(output, numStart, numEnd);
                    //cout << numString << endl;
                    int suppMod = stringToInt(numString);
                    cost += suppMod;
                }
            }
        }
    }
    /// ===========================================================
    getline(inFile, output);
    //getline(inFile, output); /// Skipping two lines here due to formatting of the document

    vector<string> aspectAdditions;
    vector<string> aspectSubtractions;

    getline(inFile, output);

    string nameAddition = "";

    for(int i = 0; i < output.size(); i++)
    {
nameAdditionStart:
        if(output[i] == ',')
        {
            i = i + 2;
            nameAddition = "";
            for(int x = i; x < output.size(); x++)
            {
                if(output[x] == ',')
                {
                    for(int y = i; y < x; y++)
                    {
                        nameAddition += output[y];
                    }
                    aspectAdditions.push_back(nameAddition);
                    goto nameAdditionStart;
                }
            }
        }
    }
    cout << "NAME ADD:" << nameAddition << endl;


    getline(inFile, output);

    string nameSubtraction = "";

    for(int i = 0; i < output.size(); i++)
    {
nameSubtractionStart:
        if(output[i] == ',')
        {
            i = i + 2;
            nameSubtraction = "";
            for(int x = i; x < output.size(); x++)
            {
                if(output[x] == ',')
                {
                    for(int y = i; y < x; y++)
                    {
                        nameSubtraction += output[y];
                    }
                    aspectSubtractions.push_back(nameSubtraction);
                    goto nameSubtractionStart;
                }
            }
        }
    }
    cout << "NAME SUB:" << nameSubtraction << endl;


    for(int i = 0; i < aspectAdditions.size(); i++)
    {
        cout << "ADDITION " << i << " " << aspectAdditions[i] << endl;
        for(int x = 0; x < basePerkAspects.size(); x++)
        {
            if(aspectAdditions[i] == basePerkAspects[x])
            {
                cout << classAspects[x] << endl;
                cost -= classAspects[x];
            }
        }
    }

    for(int i = 0; i < aspectSubtractions.size(); i++)
    {
        cout << "SUBTRACTION " << i << " " << aspectSubtractions[i] << endl;
        for(int x = 0; x < basePerkAspects.size(); x++)
        {
            if(aspectSubtractions[i] == basePerkAspects[x])
            {
                cout << classAspects[x] << endl;
                cost += classAspects[x];
            }
        }
    }

    getline(inFile, output);
    getline(inFile, output);


    /// ============================================
    for(int i = 0; i < NUMBER_OF_COLORS; i++)
    {
        getline(inFile, output);


        if(playerColors[i] == true)
        {
            int stringSize = output.size();
            int numStart;
            int numEnd;

            for(int x = 0; x < stringSize; x++)
            {
                if(output[x] == ':')
                {
                    x += 2;
                    numStart = x;
                    numEnd = stringSize - 1;
                    break;
                }
            }
            string numString = cutString(output, numStart, numEnd);
            int suppMod = stringToInt(numString);
            cost += suppMod;
        }
    }
    inFile.close();
    return cost;
}



void updatePerkCosts()
{
    for(int i = 1; i < 10; i++)
    {
        perkCosts[i].clear();

        for(int x = 0; x < perkNames[i].size(); x++)
        {
            int cost = getPerkCost(perkNames[i][x],i,player1.colors,player1.spellListSIMPLE);
            perkCosts[i].push_back(cost);
        }
    }
}


void loadClassAspects(string playerClass)
{
    ifstream inFile("../Threadlinkers Assistant/Classes/" + playerClass + ".txt");

    if(inFile.fail())
    {
        cout << "FAILED TO LOAD CHARACTER CLASS FILE. CHECK AND EDIT SPELLING AND TRY AGAIN" << endl;
        while(true)
        {

        }
    }

    string output = "";

    vector<string> loadingClassAspectNames;
    vector<int> loadingClassAspectNumbers;

    while(true)
    {
        int cutPosition = 0;
        string name = "";
        string stringCost = "";
        int cost = 0;

        getline(inFile,output);

        if(output == "/END")
        {
            break;
        }

        for(int i = 0; i < output.size(); i++)
        {
            if(output[i] == ':')
            {
                cutPosition = i;

                for(int x = 0; x < cutPosition; x++)
                {
                    name = name + output[x];
                }
                for(int x = cutPosition + 2; x < output.size(); x++)
                {
                    stringCost = stringCost + output[x];
                }
                cost = stringToInt(stringCost);
            }
        }
        loadingClassAspectNames.push_back(name);
        loadingClassAspectNumbers.push_back(cost);
    }

    classAspects.clear();

    for(int i = 0; i < basePerkAspects.size(); i++)
    {
        bool aspectFound = false;
        for(int x = 0; x < loadingClassAspectNames.size(); x++)
        {
            if(loadingClassAspectNames[x] == basePerkAspects[i])
            {
                classAspects.push_back(loadingClassAspectNumbers[x]);
                aspectFound = true;
            }
        }
        if(!aspectFound)
        {
            classAspects.push_back(0);
        }
        //cout << classAspects[i] << endl;
    }
}



void displayPerkMenuList(int selectedPerkIndex, int startingPosOfList, int level, int x, int y)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(x,y);

    int length = MENU_LIST_SIZE;
    int line = 0;

    bool lit = false;

    for(int i = startingPosOfList; i < perkNames[level].size() && i < (startingPosOfList + length); i++)
    {
        moveCursor(x,y + line);

        SetConsoleTextAttribute( hStdOut, 0x88); /// writing the left sidebar
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";

        if(i == selectedPerkIndex)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }

        //displaySpellInfo(level,i,lit);
        cout << perkNames[level][i];

        moveCursor(x+30,y + line);
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << "(" << perkCosts[level][i] << ")";

        lit = false;
        line++;
    }
    if(perkNames[level].size() < MENU_LIST_SIZE)
    {
        for(int i = perkNames[level].size(); i < MENU_LIST_SIZE; i++)
        {
            moveCursor(x,y + i);

            SetConsoleTextAttribute( hStdOut, 0x88); /// writing the left sidebar
            cout << "X";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " ";
        }
    }
}


int player::updatePeakSpellLevel()
{
    for(int i = 0; i < 10; i++)
    {
        if(spellSlots[i] > 0)
        {
            peakSlotLevel = i;
        }
    }
}

void loadSettings()
{
    ifstream inFile("settings.txt");

    string output;

    getline(inFile,output);

    CONSOLE_WIDTH = stringToInt(output);

    getline(inFile,output);

    CONSOLE_HEIGHT = stringToInt(output);
}

void characterOptions()
{
    //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Characters/001_character_names.txt");
    ifstream inFile("../Threadlinkers Assistant/Characters/001_character_names.txt");

    if(inFile.fail())
    {
        cout << "FAILED TO LOAD CHARACTER OPTIONS FILE" << endl;
    }
    else
    {
        cout << "LOADED CHARACTER OPTIONS FILE" << endl;
    }

    string fileOutput;

    while(true)
    {
        getline(inFile, fileOutput);
        if(fileOutput == "/END")
        {
            inFile.close();
            break;
        }
        else
        {
            characterOptionsInMenu.push_back(fileOutput);
        }
    }
};

void loadSpells()
{
    for(int i = 0; i < 4; i++)
    {
        spellNames[i].clear();
        //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/001_" + simpleIntToString(i) + "_names.txt");

        ifstream inFile("../Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/001_" + simpleIntToString(i) + "_names.txt");

        string output;

        cout << i << endl;
        if(inFile.fail())
        {
            cout << "File Failed to load" << endl;
        }

        while(true)
        {
            getline(inFile,output);
            if(output == "/END")
            {
                break;
            }
            spellNames[i].push_back(output);
            knownSpells[i].push_back(false);
        }
    }
};

void UpdateCosts(player player1)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));

    //cout << "Flag B_2" << endl;

    SetConsoleTextAttribute( hStdOut, 0x00);

    for(int i = 0; i < 9; i++)
    {
        moveCursor(160,0);
        spellCosts[i].clear();

        for(int x = 0; x < spellNames[i].size(); x++)
        {
            //moveCursor(0,0);
            spellCosts[i].push_back(getCost(spellNames[i][x],i,player1.colors,player1.spellListSIMPLE));
            //string name = spellNames[i][x];
            //int cost = spellCosts[i][x];
            ///int TEST = spellCosts[i][x];
            cout << 0;//TEST;//spellCosts[i][x]; // Try null?
            /// PLEASE BE THE MACHINE SPIRIT. IT DOESN"T WORK IF I DONT COUT A NUMBER EACH TIME. I HAVE NO CLUE WHY
            /// I CAN NOT ALSO RESET THE CURSOR POSITION, FOR SOME FUCKING REASON
            /// THERE IS SOME SPAGHETTI CODE SOMEWHERE, PROBABY WITH THE WINDOWS INTERFACE.

        }
    }
    SetConsoleTextAttribute( hStdOut, 0x0F);
}

void getAffinities()
{
    for(int i = 0; i < 9; i++)
    {
        for(int x = 0; x < 6; x++)
        {
            spellAffs[i][x].clear(); /// CLEARING OUT OLD DATA
        }
    }

    for(int i = 0; i < 9; i++)
    {
        for(int x = 0; x < spellNames[i].size(); x++)
        {
            string output;
            //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/" + spellNames[i][x] + ".txt");
            ifstream inFile("../Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/" + spellNames[i][x] + ".txt");
            for(int y = 0; y < 5; y++) /// REMEMBER TO UPDATE THIS 5 IF THE SPACING CHANGES
            {
                getline(inFile, output); /// SKIPPING THE FIRST 5 LINES DUE TO FORMATTING
            }
            for(int y = 0; y < 6; y++)
            {
                getline(inFile, output);
                if(output[0] == '#')
                {
                    spellAffs[i][y].push_back(true);
                }
                else
                {
                    spellAffs[i][y].push_back(false);
                }
            }
        }
    }
}


void displaySpellInfo(int level, int index, bool lit)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    int attributeDistanceFromEdge = 32;
    int costDistanceFromEdge = 25;

    int spacer2Size = costDistanceFromEdge - spellNames[level][index].size();

        string spacer = "   ";
        string spacer2 = "";

    for(int i = 0; i < spacer2Size; i++)
    {
        spacer2 = spacer2 + " ";
    }

    SetConsoleTextAttribute( hStdOut, 0x0F);

    if(lit)
    {
        SetConsoleTextAttribute( hStdOut, 0xF0);
    }

    cout << spellNames[level][index];
    SetConsoleTextAttribute( hStdOut, 0x0F);
    cout << spacer2;


    cout << "("<< spellCosts[level][index] << ")";

    cout << spacer;

    /// WHITE
    if(spellAffs[level][0][index])
    {
        SetConsoleTextAttribute( hStdOut, 0xFF);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";


    /// BLACK
    if(spellAffs[level][1][index])
    {
        SetConsoleTextAttribute( hStdOut, 0x88);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// BLUE
    if(spellAffs[level][2][index])
    {
        SetConsoleTextAttribute( hStdOut, 0x99);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// GREEN
    if(spellAffs[level][3][index])
    {
        SetConsoleTextAttribute( hStdOut, 0xAA);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// RED
    if(spellAffs[level][4][index])
    {
        SetConsoleTextAttribute( hStdOut, 0xCC);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    /// BROWN
    if(spellAffs[level][5][index])
    {
        SetConsoleTextAttribute( hStdOut, 0x66);
    }
    else
    {
        SetConsoleTextAttribute( hStdOut, 0x0F);
    }
    cout << "  ";

    SetConsoleTextAttribute( hStdOut, 0x0F);

    if(knownSpells[level][index])
    {
        cout << "   Known";
    }
    else
    {
        cout << "         ";
    }
    //cout << "test";

    //cout << knownSpells[level][index];

    //cout << "Lev: " << level << " Ind: " << index;
}


void displayDesc(int x, int y, int level, int index, int page)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    if(page == 1)
    {
        for(int i = 0; i < 35; i++)
        {
            moveCursor(x,y+i);
            cout << "                                                                                   ";
            moveCursor(x,y+i);

            SetConsoleTextAttribute( hStdOut, 0x88); /// Displaying Left Sidebar
            cout << "X";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " ";
            cout << spellDesc[level][i][index];
        }
    }

    if(page == 2)
    {
        for(int i = 35; i < 70; i++)
        {
            moveCursor(x,y+i-35);
            cout << "                                                                                   ";
            moveCursor(x,y+i-35);

            SetConsoleTextAttribute( hStdOut, 0x88); /// Displaying Left Sidebar
            cout << "X";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " ";
            cout << spellDesc[level][i][index];
        }
    }

    if(page == 3)
    {
        for(int i = 70; i < 105; i++)
        {
            moveCursor(x,y+i-70);
            cout << "                                                                                   ";
            moveCursor(x,y+i-70);

            SetConsoleTextAttribute( hStdOut, 0x88); /// Displaying Left Sidebar
            cout << "X";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " ";
            cout << spellDesc[level][i][index];
        }
    }

}

void resizeConsole()
{
    HWND console = GetConsoleWindow();
    RECT r;
    GetWindowRect(console, &r); //stores the console's current dimensions

    MoveWindow(console,0,0,CONSOLE_WIDTH,CONSOLE_HEIGHT, TRUE);
    SetWindowLong(console, GWL_STYLE, GetWindowLong(console, GWL_STYLE) & ~WS_MAXIMIZEBOX & ~WS_SIZEBOX); //https://stackoverflow.com/questions/47358043/can-i-prevent-the-user-of-my-program-to-resize-the-console-window-in-c
}

void loadSpellDescs()
{
    for(int i = 0; i < 10; i++) /// loop for the spell levels
    {
        for(int x = 0; x < spellNames[i].size(); x++) /// loop for each spell in a given level
        {
            /// Loading Spell Document
            //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/" + spellNames[i][x] + ".txt");

            ifstream inFile("../Threadlinkers Assistant/Spells/" + simpleIntToString(i) + "/" + spellNames[i][x] + ".txt");
            /// defining a var for the output of lines
            string output;

            for(int y = 0; y < 12; y++) ///skipping 12 lines to get to the description section of the spell document
            {
                getline(inFile,output);
            }

            for(int y = 0; y < DESC_LINES; y++) ///expanding the vector and filling in blank values b/c the description might not be the full set of lines
            {
                spellDesc[i][y].push_back("");
            }

            for(int y = 0; y < DESC_LINES; y++) ///reading the description and transcribing the info into the proper var
            {
                getline(inFile,output);
                if(output == "/END") ///ending the transcription if the end of the document is reached
                {
                    break;
                }

                spellDesc[i][y][x] = output;
            }
        }
    }
}


void displayBuyMenuList(int selectedSpellIndex, int startingPosOfList, int level, int x, int y)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(x,y);

    int length = MENU_LIST_SIZE;
    int line = 0;

    bool lit = false;

    for(int i = startingPosOfList; i < spellNames[level].size() && i < (startingPosOfList + length); i++)
    {
        moveCursor(x,y + line);

        SetConsoleTextAttribute( hStdOut, 0x88); /// writing the left sidebar
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";

        if(i == selectedSpellIndex)
        {
            lit = true;
        }

        displaySpellInfo(level,i,lit);

        lit = false;
        line++;
    }
}


void ShowConsoleCursor(bool showFlag)
{
    //HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

    //CONSOLE_CURSOR_INFO     cursorInfo;

    //GetConsoleCursorInfo(out, &cursorInfo);
    //cursorInfo.bVisible = showFlag; // set the cursor visibility
    //cursorInfo.dwSize = 50;
    //SetConsoleCursorInfo(out, &cursorInfo);

    /* Remove the cursor (does not work in full screen) */

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_CURSOR_INFO CursoInfo;

    CursoInfo.dwSize = 1;         /* The size of caret */

    CursoInfo.bVisible = showFlag;   /* Caret is visible? */

    SetConsoleCursorInfo(hConsole, &CursoInfo);
}


void displayHeader(int levelSelected, player player1)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(25,0);

    string headerElements[11] = {"Character","Cantrips","Level 1","Level 2","Level 3","Level 4","Level 5","Level 6","Level 7","Level 8","Level 9"};
    for(int i = 0; i < 11; i++)
    {
        SetConsoleTextAttribute(hStdOut, 0x77);
        cout << "|";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";

        if(levelSelected == (i - 1))
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        cout << headerElements[i];
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";
    }

    //if(levelSelected != -1)
    //{
        moveCursor(83,3);

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);

        //cout << " Spare Spell Points/Max Spell Points: " << player1.spareSkillPoints << "/" << player1.totalSkillPoints << " ";
        cout << " Points, Spare/Total: " << player1.spareSkillPoints << "/" << player1.totalSkillPoints << " ";

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << "  ";
    //}
}

void player::displayKnownSpells(int xPos, int yPos)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    int levelPositions[10];

    int linesWritten = 0;

    //moveCursor(0,4);
    //cout << peakSlotLevel;

    for(int i = 0; i <= peakSlotLevel; i++)
    {
        if(spells[i].size() > 0)
        {
            moveCursor(xPos + 20,yPos + linesWritten );
            //spells[i][0].size()
        }
        else
        {
            moveCursor(xPos + 2,yPos + linesWritten );
        }

        SetConsoleTextAttribute( hStdOut, 0x88);
        cout << "|";
        SetConsoleTextAttribute( hStdOut, 0x0F);

        if(i == 0)
        {
            cout << " Max Cantrips: ";
        }
        if(i == 1)
        {
            //cout << " 1st Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 2)
        {
            //cout << " 2nd Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 3)
        {
            //cout << " 3rd Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 4)
        {
            //cout << " 4th Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 5)
        {
            //cout << " 5th Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 6)
        {
            //cout << " 6th Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 7)
        {
            //cout << " 7th Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 8)
        {
            //cout << " 8th Level Spell Slots: ";
            cout << " Slots: ";
        }
        if(i == 9)
        {
            //cout << " 9th Level Spell Slots: ";
            cout << " Slots: ";
        }
        cout << spellSlots[i];
        /////////////////////////

        levelPositions[i] = linesWritten;
        for(int x = 0; x < spells[i].size(); x++)
        {
            moveCursor(xPos,yPos + linesWritten);
            SetConsoleTextAttribute( hStdOut, 0x88);
            cout << "|";
            SetConsoleTextAttribute( hStdOut, 0x0F);
            cout << " " << spells[i][x];
            linesWritten++;
        }
        moveCursor(xPos,yPos + linesWritten);
        SetConsoleTextAttribute( hStdOut, 0x88);
        cout << "|";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        linesWritten++;
    }

    string lines[10] = {"Cantrips","1st Level","2nd Level","3rd Level","4th Level","5th Level","6th Level","7th Level","8th Level","9th Level"};

    for(int i = 0; i <= peakSlotLevel; i++)
    {
        moveCursor(xPos - lines[i].size() - 1, yPos + levelPositions[i]);
        cout << lines[i];
    }

    linesWritten++;

    moveCursor(xPos - 10,yPos + linesWritten);
    cout << "Cyberware ";
    SetConsoleTextAttribute( hStdOut, 0x88);
    cout << "|";
    SetConsoleTextAttribute( hStdOut, 0x0F);


    for(int i = 0; i < augmentListSIMPLE.size(); i++)
    {
        SetConsoleTextAttribute( hStdOut, 0x88);
        moveCursor(xPos,yPos + linesWritten);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);

        moveCursor(xPos + 2,yPos + linesWritten);
        cout << augmentListSIMPLE[i];
        linesWritten++;
    }

}


void player::displayStats(int xPos, int yPos)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    SetConsoleTextAttribute(hStdOut, 0x0F);

    //string catagories[10] = {"Total Spell Points","Spare Spell Points","Max Health",""};
    moveCursor(xPos - 7,yPos);

    cout << "Health ";

    SetConsoleTextAttribute(hStdOut, 0x88);
    cout << "X";

    SetConsoleTextAttribute(hStdOut, 0x0F);
    cout << " " << maxHealth;

    SetConsoleTextAttribute(hStdOut, 0x88);
    moveCursor(xPos,yPos+1);
    cout << "X";
    SetConsoleTextAttribute(hStdOut, 0x0F);


    if(sparePhysicalStatPoints != 0)
    {
        SetConsoleTextAttribute(hStdOut, 0x06);
    }

    moveCursor(xPos - 27,yPos + 2);
    cout << "Spare Physical Stat Points ";

    SetConsoleTextAttribute(hStdOut, 0x88);
    cout << "X";
    SetConsoleTextAttribute(hStdOut, 0x0F);

    cout << " " << sparePhysicalStatPoints;

    ///
    if(spareMentalStatPoints != 0)
    {
        SetConsoleTextAttribute(hStdOut, 0x0B);
    }

    moveCursor(xPos - 25,yPos + 3);
    cout << "Spare Mental Stat Points ";

    SetConsoleTextAttribute(hStdOut, 0x88);
    cout << "X";
    SetConsoleTextAttribute(hStdOut, 0x0F);


    cout << " " << spareMentalStatPoints;
    ///

    SetConsoleTextAttribute(hStdOut, 0x88);
    moveCursor(xPos,yPos+4);
    cout << "X";
    SetConsoleTextAttribute(hStdOut, 0x0F);

    for(int i = 0; i < 7; i++)
    {
        moveCursor(xPos - (statNames[i].size() + 1), yPos + 5 + i);
        cout << statNames[i] << " ";

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << " " << realStats[i] << "  ";
    }

    SetConsoleTextAttribute(hStdOut, 0x88);
    moveCursor(xPos,yPos+13);
    cout << "X";

    SetConsoleTextAttribute(hStdOut, 0x0F);
    moveCursor(xPos - 13, yPos+13);
    cout << "(2/3) Spirit";

    SetConsoleTextAttribute(hStdOut, 0x0F);
    moveCursor(xPos + 2, yPos+13);
    cout << 2*(stats[6]/3);



    SetConsoleTextAttribute(hStdOut, 0x88);
    moveCursor(xPos,yPos+14);
    cout << "X";

    SetConsoleTextAttribute(hStdOut, 0x0F);
    moveCursor(xPos - 13, yPos+14);
    cout << "(1/3) Spirit";

    SetConsoleTextAttribute(hStdOut, 0x0F);
    moveCursor(xPos + 2, yPos+14);
    cout << stats[6]/3;


}

void updateKnownSpellsInList(player player1)
{
    for(int i = 0; i < 10; i++)
    {
        for(int x = 0; x < spellNames[i].size(); x++)
        {
            for(int y = 0; y < player1.spellListSIMPLE.size(); y++)
            {
                if(spellNames[i][x] == player1.spellListSIMPLE[y])
                {
                    knownSpells[i][x] = true;
                }
            }
        }
    }
}


void saveCharacter(player player1)
{
    //ofstream outFile("C:/001-Programs/Threadlinkers Assistant/Characters/" + player1.name + ".txt");
    ofstream outFile("../Threadlinkers Assistant/Characters/" + player1.name + ".txt");

    //outFile << "Name:" << endl;
    //outFile << player1.name << endl << endl;

    outFile << "Starting Kit:" << endl;
    outFile << player1.startingKit << endl << endl;

    outFile << "Race:" << endl;
    outFile << player1.race << endl << endl;

    outFile << "Age:" << endl;
    outFile << player1.age << endl << endl;

    outFile << "Colors:" << endl;
    for(int i = 0; i < 6; i++)
    {
        if(player1.colors[i])
        {
            if(i == 0)
            {
                outFile << "White" << endl;
            }
            if(i == 1)
            {
                outFile << "Black" << endl;
            }
            if(i == 2)
            {
                outFile << "Blue" << endl;
            }
            if(i == 3)
            {
                outFile << "Green" << endl;
            }
            if(i == 4)
            {
                outFile << "Red" << endl;
            }
            if(i == 5)
            {
                outFile << "Brown" << endl;
            }
        }
    }
    outFile << endl;

    outFile << "Total Spell Points:" << endl;
    outFile << player1.totalSkillPoints << endl << endl;

    outFile << "Spare Spell Points:" << endl;
    outFile << player1.spareSkillPoints << endl << endl;

    outFile << "Spare Physical Stat Points:" << endl;
    outFile << player1.sparePhysicalStatPoints << endl << endl;

    outFile << "Spare Mental Stat Points:" << endl;
    outFile << player1.spareMentalStatPoints << endl << endl;

    //outFile << "Health Points:" << endl;
    //outFile << player1.maxHealth << endl << endl;

    outFile << "Power:" << endl;
    outFile << player1.stats[0] << endl << endl;

    outFile << "Speed:" << endl;
    outFile << player1.stats[1] << endl << endl;

    outFile << "Dexterity:" << endl;
    outFile << player1.stats[2] << endl << endl;

    outFile << "Intellectual:" << endl;
    outFile << player1.stats[3] << endl << endl;

    outFile << "Perception:" << endl;
    outFile << player1.stats[4] << endl << endl;

    outFile << "Eloquence:" << endl;
    outFile << player1.stats[5] << endl << endl;

    for(int i = 0; i < SIZE_OF_SKILL_NAMES; i++)
    {
        outFile << GEN_SKILLS_NAMES[i] << "   " << player1.skills[i];
        if(player1.skillPips[i] == 1)
        {
            outFile << "_P";
        }
        if(player1.skillPips[i] == 2)
        {
            outFile << "_X";
        }
        outFile << endl;
    }

    outFile << endl;

    outFile << "Spells Known:" << endl;
    outFile << "=============" << endl;

    for(int i = 0; i < 10; i++)
    {
        for(int x = 0; x < player1.spells[i].size(); x++)
        {
            outFile << i << endl;
            outFile << player1.spells[i][x] << endl;
            outFile << player1.spellCosts[i][x] << endl;
        }
    }

    //outFile << "/END";
    outFile << "/CYBERWARE" << endl;

    for(int i = 0; i < 12; i++)
    {
        for(int x = 0; x < player1.augments[i].size(); x++)
        {
            outFile << i << endl;
            outFile << player1.augments[i][x] << endl;
            outFile << player1.augmentPointCosts[i][x] << endl;
            outFile << player1.augmentSpiritCosts[i][x] << endl;
            outFile << player1.augmentActive[i][x] << endl;
        }
    }

    outFile <<  "/END" << endl;

    for(int i = 0; i < 7; i++)
    {
        for(int x = 0; x < 7; x++)
        {
            outFile << player1.statModName[i][x] << endl;
            outFile << player1.statModQuant[i][x] << endl;
            outFile << player1.statModActive[i][x] << endl;
        }
    }

    outFile <<  "/RECOIL_STUFF" << endl;

    for(int i = 0; i < 8; i++)
    {
        outFile << player1.recoilName[i] << endl;
        outFile << player1.recoilAmount[i] << endl;
        outFile << player1.recoilSkill[i] << endl;
    }

    outFile << "/END";
    outFile.close();
}

void addNameToCharacterList(string name)
{
    ///We need to read the list of characters, add another one, affix the ending terminator, and overwrite the file with the new data
    vector<string> lines;

    //ifstream inFile("C:/001-Programs/Threadlinkers Assistant/Characters/001_character_names.txt");
    ifstream inFile("../Threadlinkers Assistant/Characters/001_character_names.txt");

    string output;

    while(true)
    {
        getline(inFile,output);
        if(output == "/END")
        {
            break;
        }
        else
        {
            lines.push_back(output);
        }
    }

    inFile.close();

    lines.push_back(name);
    lines.push_back("/END");

    ofstream outFile("../Threadlinkers Assistant/Characters/001_character_names.txt");

    for(int i = 0; i < lines.size(); i++)
    {
        outFile << lines[i] << endl;
    }

}

bool confirmPurchase(player player1, string name)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    moveCursor(5,3);

    SetConsoleTextAttribute( hStdOut, 0xCC);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);

    cout << " Are you sure you want to learn " << name << "? ";

    SetConsoleTextAttribute( hStdOut, 0xCC);
    cout << "X";
    SetConsoleTextAttribute( hStdOut, 0x0F);

    while(true)
    {
        int key = waitForKey();
        if(key == 89)
        {
            moveCursor(5,3);
            cout << "                                                             ";
            return true;
        }
        if(key == 78)
        {
            moveCursor(5,3);
            cout << "                                                             ";
            return false;
        }
    }
}


bool player::addSpellPoints(int numberAdded) /// Updates spell slots and stat points according to the amount of spell points added
{
    int previousTotal = totalSkillPoints;
    int staggeredPreviousTotal = totalSkillPoints + 10;

    totalSkillPoints += numberAdded;
    spareSkillPoints += numberAdded;

    int num1 = previousTotal / 20;
    int num2 = totalSkillPoints / 20;

    int num3 = staggeredPreviousTotal / 20;
    int num4 = (totalSkillPoints + 10) / 20;


    spareStatPoints = spareStatPoints + (num2 - num1);
    spareMentalStatPoints = spareMentalStatPoints + (num2 - num1);
    sparePhysicalStatPoints = sparePhysicalStatPoints + (num4 - num3);

    /// SPELL SLOTS
    /// Spell points are called skill points, thats just the way the variable worked out

    if(pointsSpentOnSpells >= 100)
    {
        spellSlots[0] = 3;
        spellSlots[1] = 2;
    }
    if(pointsSpentOnSpells >= 150)
    {
        spellSlots[1] = 3;
    }
    if(pointsSpentOnSpells >= 200)
    {
        spellSlots[1] = 3;
        spellSlots[2] = 1;
    }
    if(pointsSpentOnSpells >= 250)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 1;
    }
    if(pointsSpentOnSpells >= 300)
    {
        spellSlots[0] = 4;
        spellSlots[1] = 4;
        spellSlots[2] = 2;
    }
    if(pointsSpentOnSpells >= 350)
    {
        spellSlots[0] = 4;
        spellSlots[1] = 4;
        spellSlots[2] = 3;
    }
    if(pointsSpentOnSpells >= 400)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 3;
        spellSlots[3] = 1;
    }
    if(pointsSpentOnSpells >= 500)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 3;
        spellSlots[3] = 2;
    }
    if(pointsSpentOnSpells >= 600)
    {
        spellSlots[1] = 4;
        spellSlots[2] = 3;
        spellSlots[3] = 3;
    }

    if(spells[0].size() < 2)
    {
        spellSlots[1] = 0;
    }

    maxHealth = totalSkillPoints / 10; /// Update Health total


    if(startingKit == 1)
    {
        stats[6] = (totalSkillPoints / 20) - cumulativeSpiritPenalty + 5;
    }
    else
    {
        stats[6] = (totalSkillPoints / 20) - cumulativeSpiritPenalty;
    }

    if(spells[0].size() >= spellSlots[0])
    {
        atCantripMax = true;
    }
    else
    {
        atCantripMax = false;
    }

    updatePeakSpellLevel(); /// Updates the peak spell level value, which determines which spells are shown in the spell menu.
}

void printScrollingTest(string input, int delay)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );


    ShowConsoleCursor(false);
    int tempDelay = delay;
    for(int i = 0; i < input.size(); i++)
    {
        if(GetAsyncKeyState(16) || GetAsyncKeyState(32))
        {
            tempDelay = 2;
        }
        cout << input[i];
        Sleep(tempDelay);
        if(input[i] == '.' || input[i] == '?')
        {
            ShowConsoleCursor(true);
            Sleep(tempDelay * 10);
            ShowConsoleCursor(false);
        }
    }

}

void flush() /// resets button input buffer for normal menu stuff after cin is called and used
{
    for(int i = 10; i < 256; i++)
    {
        GetAsyncKeyState(i);
    }
}

bool player::notExceedingCantrips(int level)
{
    if(atCantripMax && level == 0)
    {
        return false;
    }
    else
    {
        return true;
    }
}

int returnStatNumber(string input)
{
    if(input == "Power" || input == "power")
    {
        return 0;
    }
    if(input == "Speed" || input == "speed")
    {
        return 1;
    }
    if(input == "Dexterity" || input == "dexterity")
    {
        return 2;
    }
    if(input == "Intellectual" || input == "intellectual" || input == "Int" || input == "int")
    {
        return 3;
    }
    if(input == "Perception" || input == "perception")
    {
        return 4;
    }
    if(input == "Eloquence" || input == "eloquence")
    {
        return 5;
    }
}

void displayColors(player player1)
{
    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    int colorsToPrint[2];

    int subIndex = 0;

    for(int i = 0; i < 6; i++)
    {
        if(player1.colors[i])
        {
            colorsToPrint[subIndex] = i;
            subIndex++;
        }
    }

    subIndex = 0;

    for(int i = 0; i < 2; i++)
    {
        if(colorsToPrint[i] == 0)
        {
            SetConsoleTextAttribute( hStdOut, 0xFF); /// full white
        }
        if(colorsToPrint[i] == 1)
        {
            SetConsoleTextAttribute( hStdOut, 0x88); /// full dark gray
        }
        if(colorsToPrint[i] == 2)
        {
            SetConsoleTextAttribute( hStdOut, 0x99); /// full blue
        }
        if(colorsToPrint[i] == 3)
        {
            //SetConsoleTextAttribute( hStdOut, 0xAA); /// full light green
            SetConsoleTextAttribute( hStdOut, 0x22);
        }
        if(colorsToPrint[i] == 4)
        {
            SetConsoleTextAttribute( hStdOut, 0xCC);
        }
        if(colorsToPrint[i] == 5)
        {
            SetConsoleTextAttribute( hStdOut, 0x66);
        }

        moveCursor(i * 82 + 1, 43);
        cout << "====================================================================================";
        //moveCursor(i * 83, 44);
        //cout << "======================================================================================";

        SetConsoleTextAttribute( hStdOut, 0x0F); // white
    }
    SetConsoleTextAttribute( hStdOut, 0x0F); // white
}


void loadAspects()
{
    ifstream inFile("../Threadlinkers Assistant/Classes/Base aspects.txt");

    if(inFile.fail())
    {
        while(true)
        {
            cout << "FAILED TO LOAD BASE ASPECTS OF CLASSES" << endl;
        }
    }

    string output = "";

    while(true)
    {
        getline(inFile,output);

        if(output != "/END")
        {
            basePerkAspects.push_back(output);
            cout << output << endl;
        }
        else
        {
            break;
        }
    }
}

void loadPerkNames()
{
    for(int i = 0; i < 10; i++)
    {
        ifstream inFile("../Threadlinkers Assistant/Abilities/" + simpleIntToString(i) + "/001_Perk_names_" + simpleIntToString(i) + ".txt");
        if(inFile.fail())
        {
            break;
        }

        string output = "";

        for(int x = 0; x < 256; x++)
        {
            getline(inFile,output);
            if(output == "/END")
            {
                break;
            }
            perkNames[i].push_back(output);
            //cout << "OUTPUT, " << x << output << "/" << endl;

            for(int y = 0; y < basePerkAspects.size(); y++) /// Initializing perk aspects (+,-, or neither) 0 == neither
            {
                //perkAspects[i][x].push_back(0);
            }
        }
    }
}


typedef struct _CONSOLE_FONT_INFOEX
{
    ULONG cbSize;
    DWORD nFont;
    COORD dwFontSize;
    UINT  FontFamily;
    UINT  FontWeight;
    WCHAR FaceName[LF_FACESIZE];
}CONSOLE_FONT_INFOEX, *PCONSOLE_FONT_INFOEX;
//the function declaration begins
#ifdef __cplusplus
extern "C" {
#endif
BOOL WINAPI SetCurrentConsoleFontEx(HANDLE hConsoleOutput, BOOL bMaximumWindow, PCONSOLE_FONT_INFOEX
lpConsoleCurrentFontEx);
#ifdef __cplusplus
}
#endif
//the function declaration ends




 void fontsize(int a, int b)
 {
  HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
  PCONSOLE_FONT_INFOEX lpConsoleCurrentFontEx = new CONSOLE_FONT_INFOEX();
  lpConsoleCurrentFontEx->cbSize = sizeof(CONSOLE_FONT_INFOEX);
  //GetCurrentConsoleFontEx(out, 0, lpConsoleCurrentFontEx);
  lpConsoleCurrentFontEx->dwFontSize.X = a;
  lpConsoleCurrentFontEx->dwFontSize.Y = b;
  SetCurrentConsoleFontEx(out, 0, lpConsoleCurrentFontEx);
 }



int main()
{
    //fontsize(8,16);
    fontsize(6,12);

    player player1;

    loadSettings();

    initializeRollValues();

    srand(static_cast<unsigned int>(time(0)));

    //////////////////////////////////////////////////////////////////

    SetConsoleTitleA("Threadlinkers Digital Character Assistant");

    HANDLE                     hStdOut;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD                      count;
    DWORD                      cellCount;
    COORD                      homeCoords = { 0, 0 };

    hStdOut = GetStdHandle( STD_OUTPUT_HANDLE );

    CONSOLE_CURSOR_INFO cursorInfo;

    bool showFlag = true;

    GetConsoleCursorInfo(hStdOut, &cursorInfo);
    cursorInfo.bVisible = showFlag; // set the cursor visibility
    SetConsoleCursorInfo(hStdOut, &cursorInfo);

    ShowConsoleCursor(false);
    //SetConsoleTextAttribute( hStdOut, 0x01); //darkBlue
    //SetConsoleTextAttribute( hStdOut, 0x02); //med-dark green
    //SetConsoleTextAttribute( hStdOut, 0x03); //turquoise
    //SetConsoleTextAttribute( hStdOut, 0x04); // darkRed
    //SetConsoleTextAttribute( hStdOut, 0x05); // Purple
    //SetConsoleTextAttribute( hStdOut, 0x06); // Dingy yellow
    //SetConsoleTextAttribute( hStdOut, 0x07); // very light gray
    //SetConsoleTextAttribute( hStdOut, 0x08); // Dark gray
    //SetConsoleTextAttribute( hStdOut, 0x09); // Blue
    //SetConsoleTextAttribute( hStdOut, 0x0A); //light green
    //SetConsoleTextAttribute( hStdOut, 0x0B); //light blue
    //SetConsoleTextAttribute( hStdOut, 0x0C); //Red
    //SetConsoleTextAttribute( hStdOut, 0x0D); // purple pink
    //SetConsoleTextAttribute( hStdOut, 0x0E); // yellow
    //SetConsoleTextAttribute( hStdOut, 0x0F); // white

    //SetConsoleTextAttribute(hStdOut,0xE1);

    loadAspects();

    loadPerkNames();

    int rightPannelOption = 0; /// For stat page, swapping between showing skills and stat mods
    int leftPannelOption = 0; /// For stat page, swapping between showing spells and recoil menu

    ///loadClassAspects("Pyromancer");

    //cout << "Cost: "  << getPerkCost("Perk Test", 1,player1.colors,player1.spellListSIMPLE) << endl;

    ///updatePerkCosts();

    //cout << perkNames[1][0] << " Costs: " << perkCosts[1][0] << endl;

    ClearScreen();

    //displayPerkMenuList(0,0,1,5,5);

    resizeConsole();

    moveCursor(0,0);
    ClearScreen();

    loadAugments();

    loadAugmentDescs();

    //displayAugmentDesc(83,5,0,0,1);

    //displayAugmentSidebar(0);

    //displayAugmentInfo(0,0,18,5,0,player1);
    //displayAugmentInfo(0,1,18,6,0,player1);

    ClearScreen();

    //goto Cyberware;

    //while(true)
    //{

    //}

/////////////////////////////////////////////////////////////////////////////

menu: /// MENU MENU MENU
{
    ClearScreen();
    moveCursor(0,0);

    resizeConsole();

    ShowConsoleCursor(false);

    //SetConsoleTextAttribute( hStdOut, 0xCC);
   // moveCursor(166,13);
    //cout << "XXX";
    //moveCursor(0,0);

    SetConsoleTextAttribute( hStdOut, 0x0F);

    ifstream inFile("title_art.txt");
    if(inFile.fail())
    {
        cout << "Failed to load file: title_art.txt" << endl;
    }
    string output;

    for(int i = 0; i < 13; i++) /// Displaying Title Art
    {
        getline(inFile,output);
        cout << output << endl;
    }

    SetConsoleTextAttribute( hStdOut, 0xFF);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x88);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x99);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0xAA);
    cout << "XXXXXXXXXXX      XXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0xCC);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x66);
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXX";

    SetConsoleTextAttribute( hStdOut, 0x0F);

    inFile.close();

    resizeConsole();

    bool menuLoop = true;
    bool flipFlop;

    int menuOption = 0;

    int OPTIONS_HORO = 76;
    int OPTIONS_VERT = 20;

    while(menuLoop) /// MAIN MENU LOOP
    {
        resizeConsole();

        mouse.update();
        //moveCursor(0,0);
        //cout << "         ";
        //moveCursor(0,0);
        //cout << mouse.x << "," << mouse.y;

        /// OPTION 0
        moveCursor(OPTIONS_HORO,OPTIONS_VERT);

        if(mouse.y < (OPTIONS_VERT+1))
        {
            menuOption = 0;
        }
        if(mouse.y > (OPTIONS_VERT) && mouse.y <= (OPTIONS_VERT+1))
        {
            menuOption = 1;
        }
        if(mouse.y > (OPTIONS_VERT+1))
        {
            menuOption = 2;
        }

        if(menuOption == 0)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
            cout << "New Character";
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        else
        {
            cout << "New Character";
        }

        /// OPTION 1
        moveCursor(OPTIONS_HORO,OPTIONS_VERT + 1);
        if(menuOption == 1)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
            cout << "Load Character";
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        else
        {
            cout << "Load Character";
        }

        /// OPTION 2
        //moveCursor(OPTIONS_HORO,OPTIONS_VERT + 2);
        //if(menuOption == 2)
        //{
            //SetConsoleTextAttribute( hStdOut, 0xF0);
            //cout << "Options";
            //SetConsoleTextAttribute( hStdOut, 0x0F);
        //}
        //else
        //{
            //cout << "Options";
        //}

        /// OPTION 3
        //moveCursor(OPTIONS_HORO,OPTIONS_VERT + 3);
        //if(menuOption == 3)
        //{
            //SetConsoleTextAttribute( hStdOut, 0xF0);
            //cout << "DEBUG";
            //SetConsoleTextAttribute( hStdOut, 0x0F);
        //}
        //else
        //{
            //cout << "DEBUG";
        //}

        if(keyPressed(83))
        {
            menuOption++;
            if(menuOption == 2) /// NUMBER OF MENU OPTIONS
            {
                menuOption = 1;
            }
        }

        if(keyPressed(87))
        {
            menuOption--;
            if(menuOption == -1)
            {
                menuOption = 0;
            }
        }

        if((keyPressed(13) || mouse.singleLeftClick)&& menuOption == 0)
        {
            goto newCharacter;
        }
        if((keyPressed(13) || mouse.singleLeftClick) && menuOption == 1)
        {
            goto loadCharacter;
        }
        //if((keyPressed(13) || mouse.singleLeftClick) && menuOption == 2)
        //{
            //goto settingsMenu;
        //}
        Sleep (50);
    }
}

settingsMenu:
{
    ClearScreen();

    int xPosMenu = 83;
    int yPosMenu = 10;

    int menuOptions = 5;

    int menuOption = 0;

    string options[5] = {"Increase Width", "Decrease Width","Increase Height","Decrease Height", "Return to Main Menu"};

    while(true)
    {
        Sleep(100);
        mouse.update();
        moveCursor(0,0);
        cout << menuOption << endl << mouse.y;

        for(int i = 0; i < menuOptions; i++)
        {
            SetConsoleTextAttribute( hStdOut, 0x0F); // white
            if(mouse.y == yPosMenu + i)
            {
                menuOption = i;
                SetConsoleTextAttribute( hStdOut, 0xF0); // inverted
            }
            moveCursor(xPosMenu,yPosMenu + i);
            cout << options[i];
        }
        SetConsoleTextAttribute( hStdOut, 0x0F); // white

        if(mouse.singleLeftClick && menuOption == 0)
        {
            modifySettings(5,0);
            loadSettings();
            resizeConsole();
        }
        if(mouse.singleLeftClick && menuOption == 1)
        {
            modifySettings(-5,0);
            loadSettings();
            resizeConsole();
        }
        if(mouse.singleLeftClick && menuOption == 2)
        {
            modifySettings(0,5);
            loadSettings();
            resizeConsole();
        }
        if(mouse.singleLeftClick && menuOption == 3)
        {
            modifySettings(0,-5);
            loadSettings();
            resizeConsole();
        }
        if(mouse.singleLeftClick && menuOption == 4)
        {
            goto menu;
        }
    }
}

loadCharacter: /// LOAD CHARACTER LOAD CHARACTER LOAD CHARACTER
{
    ClearScreen();
    characterOptionsInMenu.clear();

    characterOptions();




    if(characterOptionsInMenu.size() == 0)
    {
        goto menu;
    }

    Sleep(100);
    ClearScreen();

    int menuOption = 0;

    characterOptionsInMenu.push_back("[Main Menu]"); /// ADDING AN EXTRA OPTION WHICH WILL SEND THE PLAYER BACK TO THE MAIN MENU

    while(true)
    {

        resizeConsole();

        for(int i = 0; i < characterOptionsInMenu.size(); i++)
        {
            SetConsoleTextAttribute( hStdOut, 0x0F);
            //if(i == menuOption)
            //{
                //SetConsoleTextAttribute( hStdOut, 0xF0);
            //}

            if(mouse.y > (9 + i) && mouse.y < (11 + i))
            {
                menuOption = i;
                SetConsoleTextAttribute( hStdOut, 0xF0);
            }

            moveCursor(80,10+i);
            cout << characterOptionsInMenu[i];
        }
        mouse.update();


        ///OLD CODE
        //if(keyPressed(83))
        //{
            //menuOption++;
            //if(menuOption == characterOptionsInMenu.size())
            //{
                //menuOption = characterOptionsInMenu.size() -1;
            //}
        //}

        //if(keyPressed(87))
        //{
            //menuOption--;
            //if(menuOption == -1)
            //{
                //menuOption = 0;
            //}
        //}
        ///END OF OLD CODE

        if(keyPressed(13) || mouse.singleLeftClick)
        {
            //cout << "flag B";
            player1.name = characterOptionsInMenu[menuOption];
            //cout << "flag A";

            if(player1.name == "[Main Menu]")
            {
                SetConsoleTextAttribute( hStdOut, 0x0F);
                Sleep(100);
                characterOptionsInMenu.pop_back();
                goto menu;
            }
            else
            {
                goto playerMenu;
            }
        }

        if(keyPressed(16))
        {
            goto menu;
        }

        Sleep(100);
        //ClearScreen();
    }

    goto menu;
}



playerMenu:

    player1.loadData(); /// Loads information from player document

    //player1.statModName[0][0] = "YETTI";

    //saveCharacter(player1);

    loadSpells(); /// Loads spells from spell documents
    //cout <<  "Flag B" << endl;
    //cout << spellNames[0][0] << endl;
    UpdateCosts(player1); /// update spell costs according to player spells and colors
    //cout << "Flag C" << endl;
    getAffinities(); /// Retrieves the color affinities from the spell documents for all the spells
    loadSpellDescs(); /// Load the descriptions for all of the spells

    updateKnownSpellsInList(player1); /// Makes sure the menu shows which spells are known or not, this starts it out

    player1.updatePeakSpellLevel();

    ShowConsoleCursor(false);

    mouse.reset();

    player1.addSpellPoints(0);

    //while(true)
    //{
        //cout << player1.stats[6] << endl;
    //}

playerMenuLater:
{
    moveCursor(0,0);
    ClearScreen();

    displayColors(player1); /// Displays the players colors at the bottom

    int level = 0;
    int selectorPos = 0;
    int previousSelectorPos = 0;
    int listStartPos = 0;

    int page = 1;

    SetConsoleTextAttribute( hStdOut, 0x0F);
    displayBuyMenuList(selectorPos,listStartPos,level,5,5);

    displayDesc(83,5,level,selectorPos,page);

    int testVar = 0;

    hasCharacteristicCantrips = false;
    hasCharacteristicSpells = false;

    bool displayedDesc = false;

    bool previouslyRightClicking = false;
    int rightClickPosition = 0;

    while(true) /// SPELL MENU LOOP
    {



    ///

    if(player1.spells[0].size() >= 2) /// Code that makes the first two cantrips and spells free
    {
        hasCharacteristicCantrips = true;
    }
    if(player1.spells[1].size() >= 2)
    {
        hasCharacteristicSpells = true;
    }
    if(player1.augmentListSIMPLE.size() < 2)
    {
        player1.casterStart = true;
    }
    if(player1.startingKit != 1)
    {
        player1.casterStart = false;
    }

    if(!hasCharacteristicCantrips && player1.casterStart)
    {
        for(int i = 0; i < spellCosts[0].size(); i++)
        {
            spellCosts[0][i] = 0;
        }
    }
    if(!hasCharacteristicSpells && player1.casterStart)
    {
        for(int i = 0; i < spellCosts[1].size(); i++)
        {
            spellCosts[1][i] = 0;
        }
    }

    /// End of the code that makes the first 2 cantrips and spells free

        SetConsoleTextAttribute( hStdOut, 0xF0);
        moveCursor(0,0);
        //cout << testVar;
        displayHeader(level, player1);

        SetConsoleTextAttribute( hStdOut, 0x0F);
        displayBuyMenuList(selectorPos,listStartPos,level,5,5);

        if(!displayedDesc)
        {
            displayDesc(83,5,level,selectorPos,page);
            displayedDesc = true;
        }

        SetConsoleTextAttribute( hStdOut, 0x00);

        //testVar ++;

        ///int key = waitForKey();

        SetConsoleTextAttribute( hStdOut, 0x0F);

        mouse.update();
        //moveCursor(0,0);
        //cout << "         ";
        //moveCursor(0,0);
        //cout << mouse.x << "," << mouse.y;


        int key = getKey();

        resizeConsole();


        if(keyPressed(27))
        {
            goto menu;
        }

        if((keyPressed(13) || mouse.singleLeftClick) && mouse.y > 2 && !knownSpells[level][selectorPos] && spellCosts[level][selectorPos] <= player1.spareSkillPoints && confirmPurchase(player1,spellNames[level][selectorPos]) && player1.spellSlots[level] != 0 && player1.notExceedingCantrips(level))
        {
            if(!hasCharacteristicCantrips)
            {
                player1.spellCosts[level].push_back(50);
                player1.pointsSpentOnSpells += 50;
            }
            else
            {
                player1.spellCosts[level].push_back(spellCosts[level][selectorPos]);
                player1.pointsSpentOnSpells += spellCosts[level][selectorPos];
            }


            player1.spells[level].push_back(spellNames[level][selectorPos]);
            player1.spellListSIMPLE.push_back(spellNames[level][selectorPos]);


            player1.spareSkillPoints -= spellCosts[level][selectorPos];

            if(player1.spells[0].size() >= player1.spellSlots[0])
            {
                player1.atCantripMax = true;
            }
            else
            {
                player1.atCantripMax = false;
            }

            UpdateCosts(player1);
            updateKnownSpellsInList(player1);
            saveCharacter(player1);

            player1.addSpellPoints(0);
            ///goto playerMenuLater; /// FIX THIS LATER
        }


        if(mouse.x > 4 && mouse.x < 40 && mouse.y > 4) /// Right Click Scrolling
        {
            //moveCursor(0,1);
            //cout << mouse.holdingRightClick;
            //moveCursor(0,2);
            //cout << previouslyRightClicking;
            //moveCursor(0,3);
            //cout << mouse.singleRightClick;

            if(previouslyRightClicking && (mouse.holdingRightClick == false))
            {
                previouslyRightClicking = false;
            }
            if(previouslyRightClicking && (rightClickPosition != mouse.y))
            {
                listStartPos -= (mouse.y - rightClickPosition);
                rightClickPosition = mouse.y;
            }
            if(mouse.singleRightClick)
            {
                previouslyRightClicking = true;
                rightClickPosition = mouse.y;
            }
        }


        if(listStartPos + MENU_LIST_SIZE > spellNames[level].size())
            {
                listStartPos = spellNames[level].size() - MENU_LIST_SIZE;
            }
            if(listStartPos < 0)
            {
                listStartPos = 0;
            }





        if(mouse.x < 4) /// Left Sidebar Scrolling
        {
            int listSize = spellNames[level].size();
            int numberOfSpareSpells = listSize - (25);

            if(listSize < 1)
            {
                goto outOfScrollFunction;
            }

            int notchSize = numberOfSpareSpells / (25);

            for(int i = 0; i < mouse.y - 5; i++)
            {
                if((i % notchSize) < 3)
                {
                    listStartPos = notchSize * i;
                }
            }

            if(listStartPos + MENU_LIST_SIZE > spellNames[level].size())
            {
                listStartPos = spellNames[level].size() - MENU_LIST_SIZE;
            }
            if(listStartPos < 0)
            {
                listStartPos = 0;
            }
            if(selectorPos >= spellNames[level].size())
            {
                selectorPos = spellNames[level].size() - 1;
            }
        }
outOfScrollFunction:


        //if(key == 83 && selectorPos < spellNames[level].size() - 1)
        //{
            //selectorPos++;
        //}
        //if(key == 87 && selectorPos > 0)
        //{
            //selectorPos--;
        //}


        if(mouse.singleLeftClick && mouse.y < 2)
        {
            if(mouse.x > 24 && mouse.x < 37)
            {
                level = -1;
                goto playerStatPage;
            }
            if(mouse.x > 37 && mouse.x < 48)
            {
                level = 0;
            }
            if(mouse.x > 48 && mouse.x < 58)
            {
                level = 1;
            }
            if(mouse.x > 58 && mouse.x < 68)
            {
                level = 2;
            }
            if(mouse.x > 68 && mouse.x < 78)
            {
                level = 3;
            }
        }

        if(key == 83 && (listStartPos + MENU_LIST_SIZE) < spellNames[level].size())
        {
            listStartPos++;
        }
        if(key == 87 && listStartPos > 0)
        {
            listStartPos--;
        }

        if(mouse.x > 2 && mouse.x < 30 && mouse.y >= 5)
        {
            selectorPos = mouse.y-5+listStartPos;

            if(selectorPos != previousSelectorPos)
            {
                displayedDesc = false;
                previousSelectorPos = selectorPos;
            }
        }

        if(selectorPos < 0)
        {
            selectorPos = 0;
            displayedDesc = true;
        }
        if(selectorPos > spellNames[level].size())
        {
            selectorPos = spellNames[level].size();
            displayedDesc = true;
        }

        if(key == 49)
        {
            page = 1;
            displayDesc(83,5,level,selectorPos,page);
        }
        if(key == 50)
        {
            page = 2;
            displayDesc(83,5,level,selectorPos,page);
        }
        if(key == 51)
        {
            page = 3;
            displayDesc(83,5,level,selectorPos,page);
        }




        if(key == 68)
        {
            level++;
            if(level > player1.peakSlotLevel) /// MAX LEVEL ON SPELL MENU, TEMPORARILLY SET TO 3
            {
                level = player1.peakSlotLevel;
            }

            if(listStartPos + MENU_LIST_SIZE > spellNames[level].size())
            {
                listStartPos = spellNames[level].size() - MENU_LIST_SIZE;
            }
            if(selectorPos >= spellNames[level].size())
            {
                selectorPos = spellNames[level].size() - 1;
            }
        }
        if(key == 65)
        {
            level--;

            if(level < 0)
            {

                goto playerStatPage;
                level = 0;
            }

            if(listStartPos + MENU_LIST_SIZE > spellNames[level].size())
            {
                listStartPos = spellNames[level].size() - MENU_LIST_SIZE;
            }
            if(selectorPos >= spellNames[level].size())
            {
                selectorPos = spellNames[level].size() - 1;
            }
        }



        moveCursor(148,0);
        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";

        SetConsoleTextAttribute( hStdOut, 0x00);
        cout << " ";

        SetConsoleTextAttribute( hStdOut, 0xF0);
        cout << "Psionics";

        SetConsoleTextAttribute( hStdOut, 0x0F);
        moveCursor(148,1);

        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";

        SetConsoleTextAttribute( hStdOut, 0x0F);

        cout << " Cyberware";

        if(mouse.singleLeftClick && mouse.x > 149 && mouse.x < 156 && mouse.y > 0 && mouse.y < 2)
        {
            ClearScreen();
            goto Cyberware;
        }
    }
}

playerStatPage:
{
    ClearScreen();
    moveCursor(0,0);
    int level = -1;
    displayHeader(level,player1);

    moveCursor(0,2);

    player1.addSpellPoints(0); /// Updates spell slots


    if(leftPannelOption == 0)
    {
        player1.displayKnownSpells(12,5); /// make sure to update other if moved
    }

    saveCharacter(player1);

    int menuOption = 0;
    int numberOfMenuItems = 2;

    int xPosStats = 83;
    int yPosStats = 5;

    int xPosMenu = 83;
    int yPosMenu = 21;

    int selectedSkill = 0;
    int statBracket = 0;

    mouse.reset();

    player1.updateRealStats();

    player1.updateFinalSkillTotals();

    while(true)
    {
statPageLoop:

    displayColors(player1);

        mouse.update();
        moveCursor(0,0);

        //cout << "         ";
        moveCursor(0,0);
        cout << "      ";
        moveCursor(0,0);
        cout << mouse.x << "," << mouse.y;

        if(keyPressed(27))
        {
            goto menu;
        }

        if(mouse.singleLeftClick && mouse.y < 2 && mouse.x < 140 && mouse.x > 25) /// HEADER BAR MENU SELECTOR
        {
            player1.addSpellPoints(0);
            if(mouse.x > 24 && mouse.x < 37)
            {
                level = -1;
            }
            if(mouse.x > 37 && mouse.x < 48)
            {
                level = 0;
                goto playerMenuLater;
            }
            if(mouse.x > 48 && mouse.x < 58)
            {
                level = 1;
                goto playerMenuLater;
            }
            if(mouse.x > 58 && mouse.x < 68)
            {
                level = 2;
                goto playerMenuLater;
            }
            if(mouse.x > 68 && mouse.x < 78)
            {
                level = 3;
                goto playerMenuLater;
            }
        }

        resizeConsole();
        /// FIRST MENU OPTION
        moveCursor(xPosMenu,yPosMenu);
        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << " ";
        if(menuOption == 0)
        {
            SetConsoleTextAttribute(hStdOut, 0xf0);

        }
        cout << "Add Spell Points";

        if(mouse.y == 22 && mouse.x < 105)
        {
            menuOption = 1;
        }
        else if(mouse.y == 21 && mouse.x < 105)
        {
            menuOption = 0;
        }
        else if(mouse.y == 23 && mouse.x < 105)
        {
            menuOption = 2;
        }
        else if(mouse.y == 24 && mouse.x < 105)
        {
            menuOption = 3;
        }
        else if(mouse.y == 25 && mouse.x < 105)
        {
            menuOption = 4;
        }
        else if(mouse.y == 26 && mouse.x < 105)
        {
            menuOption = 5;
        }
        else if(mouse.x > 124 && mouse.x < 154)
        {
            menuOption = -1;
            selectedSkill = mouse.y - 3;

            if(selectedSkill < 0)
            {
                selectedSkill = 0;
            }
            if(selectedSkill > SIZE_OF_SKILL_NAMES - 1)
            {
                selectedSkill = SIZE_OF_SKILL_NAMES - 1;
            }

            for(int i = 0; i < 7; i++)
            {
                if(selectedSkill >= SKILL_LIST_HEADER_POSITIONS[i] && selectedSkill < SKILL_LIST_HEADER_POSITIONS[i+1])
                {
                    SetConsoleTextAttribute( hStdOut, 0x99);
                    statBracket = i;
                    moveCursor(68,10+i);
                    cout << "X";
                }
                else
                {
                    SetConsoleTextAttribute( hStdOut, 0x0F);
                    moveCursor(68,10+i);
                    cout << " ";
                }
            }
        }



        if(menuOption == 0 && (keyPressed(13) || mouse.singleLeftClick) && mouse.x < 110 && mouse.x > 83)
        {

            Sleep(200);

            SetConsoleTextAttribute(hStdOut, 0x0F);

            cout << " How Many? ";
            ShowConsoleCursor(true);

            cin.clear();

            FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE)); /// VERY IMPORTANT https://stackoverflow.com/questions/8468514/getasynckeystate-creating-problems-with-cin?rq=1
            //https://stackoverflow.com/questions/257091/how-do-i-flush-the-cin-buffer


            string numberInput = "";

            cin >> numberInput;

            //getline(cin,numberInput);
            ShowConsoleCursor(false);
            moveCursor(xPosMenu+18,yPosMenu);
            cout << "                ";
            Sleep(200);

            SetConsoleTextAttribute( hStdOut, 0x0F);

            int spellPointsAdded = stringToInt(numberInput);

            player1.addSpellPoints(spellPointsAdded);


            if(leftPannelOption == 0)
            {
                player1.displayKnownSpells(12,5); /// Make sure to update other if moved
            }

            saveCharacter(player1);

            player1.updateRealStats();

            Sleep(200);
        }

        player1.displayStats(xPosStats,yPosStats);
        player1.addSpellPoints(0); /// Updates spell slots

        /// SECOND MENU OPTION
        moveCursor(xPosMenu, yPosMenu + 1);
        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << " ";
        if(menuOption == 1)
        {
            SetConsoleTextAttribute(hStdOut, 0xf0);
        }
        cout << "Apply Stat Points";

        SetConsoleTextAttribute(hStdOut, 0x0F);

        int subMenuOption = 0;
forgiveMe: /// Don't ask, it hitches if i don't reset the loop like this, not sure why, and I don't care enough at this point
           /// The loop in question is the stat add loop, and it has problems when you confirm, the check for the enter
           /// key (button 13) always passes after passing once, even if the button is no longer held
        if(menuOption == 1 && (keyPressed(13) || mouse.singleLeftClick) && mouse.x < 110 && mouse.x > 83)
        {

            Sleep(250);
            while(true)
            {
                mouse.update();
                subMenuOption = mouse.y - 10;

                if(subMenuOption > 5)
                {
                    subMenuOption = 5;
                }
                if(subMenuOption < 0)
                {
                    subMenuOption = 0;
                }

                for(int i = 0; i < 6; i++)
                {
                    if(subMenuOption == i)
                    {
                        SetConsoleTextAttribute(hStdOut, 0xF0);
                    }

                    moveCursor(90,10+i);
                    cout << "+";
                    SetConsoleTextAttribute(hStdOut, 0x0F);
                }
                if(keyPressed(83))
                {
                    subMenuOption++;
                    if(subMenuOption == 6)
                    {
                        subMenuOption--;
                    }
                }

                if(keyPressed(87))
                {
                    subMenuOption--;
                    if(subMenuOption == -1)
                    {
                        subMenuOption = 0;
                    }
                }

                if(keyPressed(16) || mouse.singleRightClick)
                {
                    SetConsoleTextAttribute(hStdOut, 0x0F);
                    for(int i = 0; i < 6; i++)
                    {
                        moveCursor(90,10+i);
                        cout << "   ";
                    }
                    goto statPageLoop;
                }

                if((keyPressed(13) || mouse.singleLeftClick) && subMenuOption <= 2 && player1.sparePhysicalStatPoints > 0)
                {
                    moveCursor(92,10+subMenuOption);
                    cout << "How many? ";
                    string input;
                    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
                    cin >> input;

                    if(stringToInt(input) <= player1.sparePhysicalStatPoints)
                    {
                        player1.stats[subMenuOption] += stringToInt(input);
                        player1.sparePhysicalStatPoints -= stringToInt(input);
                    }

                    moveCursor(92,10+subMenuOption);
                    cout << "              ";
                    player1.addSpellPoints(0);
                    player1.updateRealStats();
                    player1.displayStats(xPosStats,yPosStats); /// XXXXXXXXXXXXXXXXX
                    saveCharacter(player1);
                    goto forgiveMe;
                }

                if((keyPressed(13) || mouse.singleLeftClick) && subMenuOption >= 3 && player1.spareMentalStatPoints > 0)
                {
                    moveCursor(92,10+subMenuOption);
                    cout << "How many? ";
                    string input;
                    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
                    cin >> input;

                    if(stringToInt(input) <= player1.spareMentalStatPoints)
                    {
                        player1.stats[subMenuOption] += stringToInt(input);
                        player1.spareMentalStatPoints -= stringToInt(input);
                    }

                    moveCursor(92,10+subMenuOption);
                    cout << "            ";
                    player1.addSpellPoints(0);
                    player1.updateRealStats();
                    player1.displayStats(xPosStats,yPosStats); /// XXXXXXXXXXXXXXXXX
                    saveCharacter(player1);
                    goto forgiveMe;
                }

                Sleep(60);
            }
        }

        moveCursor(xPosMenu,yPosMenu+2);
        SetConsoleTextAttribute( hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";


        if(menuOption == 2)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);

        }
        else
        {
            SetConsoleTextAttribute( hStdOut, 0x0F);

        }
        cout << "Modify Spare Points";
        SetConsoleTextAttribute( hStdOut, 0x0F);

        if(menuOption == 2 && (keyPressed(13) || mouse.singleLeftClick) && mouse.x < 110 && mouse.x > 83)
        {
            moveCursor(xPosMenu+21,yPosMenu +2);
            cout << " How Many? ";

            FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE)); /// VERY IMPORTANT https://stackoverflow.com/questions/8468514/getasynckeystate-creating-problems-with-cin?rq=1
            //https://stackoverflow.com/questions/257091/how-do-i-flush-the-cin-buffer


            string numberInput = "";

            cin >> numberInput;

            //getline(cin,numberInput);
            ShowConsoleCursor(false);
            moveCursor(xPosMenu+21,yPosMenu+2);
            cout << "                ";
            Sleep(200);
            SetConsoleTextAttribute( hStdOut, 0x0F);

            player1.spareSkillPoints += stringToInt(numberInput);
            saveCharacter(player1);
        }

        moveCursor(xPosMenu,yPosMenu+3);
        SetConsoleTextAttribute( hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";


        if(menuOption == 3)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        else
        {
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        cout << "Increase Skill (+1)";
        SetConsoleTextAttribute( hStdOut, 0x0F);

        if(menuOption == 3 && (keyPressed(13) || mouse.singleLeftClick) && mouse.x < 110 && mouse.x > 83)
        {
            player1.skills[selectedSkill] += 1;
            saveCharacter(player1);
            Sleep(150);
        }

        moveCursor(xPosMenu,yPosMenu+4); /// OPTION #4
        SetConsoleTextAttribute( hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";

        if(menuOption == 4)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        else
        {
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        cout << "Decrease Skill (-1)";
        SetConsoleTextAttribute( hStdOut, 0x0F);

        if(menuOption == 4 && (keyPressed(13) || mouse.singleLeftClick) && mouse.x < 110 && mouse.x > 83)
        {
            player1.skills[selectedSkill] -= 1;
            saveCharacter(player1);
            Sleep(150);
        }

        moveCursor(xPosMenu,yPosMenu+5); /// OPTION #5
        SetConsoleTextAttribute( hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " ";

        if(menuOption == 5)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        else
        {
            SetConsoleTextAttribute( hStdOut, 0x0F);
        }
        cout << "Roll Pips";
        SetConsoleTextAttribute( hStdOut, 0x0F);


        if(menuOption == 5 && mouse.singleLeftClick && mouse.x < 110 && mouse.x > 83)
        {
            player1.rollPips();
            saveCharacter(player1);
            Sleep(150);
        }

/// ================================================================ END OF MENU OPTIONS

        if(keyPressed(83))
        {
            menuOption++;
            if(menuOption == numberOfMenuItems)
            {
                menuOption--;
            }
        }

        if(keyPressed(87))
        {
            menuOption--;
            if(menuOption == -1)
            {
                menuOption = 0;
            }
        }

        moveCursor(0,0);
        displayHeader(level,player1);
        player1.displayStats(83,5); /// make sure to update other occurance if changed (see above for X's)
        //int key = waitForKey();

        int key = getKey();

        SetConsoleTextAttribute(hStdOut, 0x0F);
        //moveCursor(50,10);
        //cout << key;

        if(key == 68)
        {
            level = 0;
            goto playerMenuLater;
        }


        for(int i = 0; i < 39; i++) /// DISPLAYING SKILLS
        {
            if(rightPannelOption != 0)
            {
                break;
            }

            int xPosSkills = 125;
            moveCursor(xPosSkills,3+i);

            player1.updateFinalSkillTotals();

            if(i == selectedSkill)
            {
                SetConsoleTextAttribute(hStdOut, 0xF0);
            }
            else
            {
                SetConsoleTextAttribute(hStdOut, 0x0F);
            }

            cout << GEN_SKILLS_NAMES[i];
            SetConsoleTextAttribute(hStdOut, 0x88);
            moveCursor(xPosSkills + 20,3+i);
            cout << "X";

            if(i == selectedSkill)
            {
                SetConsoleTextAttribute(hStdOut, 0xF0);
            }
            else
            {
                SetConsoleTextAttribute(hStdOut, 0x0F);
            }

            cout << " " << player1.skills[i];

            moveCursor(xPosSkills + 25,3+i);
            SetConsoleTextAttribute(hStdOut, 0x88);
            cout << "X";

            if(i == selectedSkill)
            {
                SetConsoleTextAttribute(hStdOut, 0xF0);
            }
            else
            {
                SetConsoleTextAttribute(hStdOut, 0x0F);
            }

            cout << " " << player1.skillTotals[i];

            /// Check to see if a skill is in a stat bracket (for the white bar on the left)
            if(i >= SKILL_LIST_HEADER_POSITIONS[statBracket] && i < SKILL_LIST_HEADER_POSITIONS[statBracket+1])
            {
                SetConsoleTextAttribute(hStdOut, 0x99);
                moveCursor(xPosSkills - 2, 3+i);
                cout << "X";
                SetConsoleTextAttribute(hStdOut, 0x0F);
            }
            else
            {
                SetConsoleTextAttribute(hStdOut, 0x0F);
                moveCursor(xPosSkills - 2, 3+i);
                cout << " ";
            }

        }


        for(int i = 0; i < 7; i++) /// DISPLAYING STAT MOD MENU
        {
            if(rightPannelOption != 1)
            {
                break;
            }

            SetConsoleTextAttribute( hStdOut, 0x88);

            int lengthOfSideBars = (35 - NAMES_OF_STATS[i].size() - 2)/2;

            moveCursor(125, 3 + (5 * i));

            for(int x = 0; x < lengthOfSideBars; x++)
            {
                cout << "X";
            }

            SetConsoleTextAttribute( hStdOut, 0x0F);

            cout << " " << NAMES_OF_STATS[i] << " ";

            SetConsoleTextAttribute( hStdOut, 0x88);

            if( ((2*lengthOfSideBars) + NAMES_OF_STATS[i].size() + 2) < 35)
            {
                lengthOfSideBars++;
            }
            else if( ((2*lengthOfSideBars) + NAMES_OF_STATS[i].size() + 2) > 35)
            {
                lengthOfSideBars--;
            }

            for(int x = 0; x < lengthOfSideBars; x++)
            {
                cout << "X";
            }

            SetConsoleTextAttribute( hStdOut, 0x0F);

            for(int x = 0; x < 4; x++)
            {
                moveCursor(125, 4 + (5 * i) + x);
                SetConsoleTextAttribute( hStdOut, 0x0F);
                cout << player1.statModName[i][x];

                moveCursor(154, 4 + (5 * i) + x);
                if(player1.statModQuant[i][x] != 0)
                {
                    cout << player1.statModQuant[i][x];
                }
                else
                {
                    cout << "    ";
                }
                SetConsoleTextAttribute( hStdOut, 0x0F);

                moveCursor(158, 4 + (5 * i) + x);
                if(player1.statModActive[i][x] == 1)
                {
                    SetConsoleTextAttribute( hStdOut, 0x99);
                    cout << "XX";
                }
                if(player1.statModActive[i][x] == 2)
                {
                    SetConsoleTextAttribute( hStdOut, 0x44);
                    cout << "XX";
                }
                if(player1.statModActive[i][x] == 0)
                {
                    cout << "  ";
                }
            }
        }


        /// These two variables translate a given y value to the correct address for the stat Modifier slots
        /// The first one gives the first coordinate in that array, and the second the second. The first one corresponds to the stat, and the second
        /// Which slot for that stat. A value of -1 value tells the code that that y coord does not correspond to a slot
        ///                     0  1  2  3 4 5 6 7 8
        int statSpot[50]    = {-1,-1,-1,-1,0,0,0,0,-1,1,1,1,1,-1,2,2,2,2,-1,3,3,3,3,-1,4,4,4,4,-1,5,5,5,5,-1,6,6,6,6,6,6,6,6};


        int subStatSpot[50] = {-1,-1,-1,-1,0,1,2,3,-1,0,1,2,3,-1,0,1,2,3,-1,0,1,2,3,-1,0,1,2,3,-1,0,1,2,3,-1,0,1,2,3,-1,0,1,2,3};

        if(mouse.singleLeftClick && mouse.y > 3 && mouse.x > 125 && mouse.x < 154 && rightPannelOption == 1 && statSpot[mouse.y] != -1) /// changing statMod names
        {
            if(statSpot[mouse.y] == -1)
            {
                break;
            }
            moveCursor(125,mouse.y);
            cout << "                ";
            moveCursor(125,mouse.y);

            string input;
            FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
            flush();
            getline(cin,input);
            player1.statModName[statSpot[mouse.y]][subStatSpot[mouse.y]] = input;
            saveCharacter(player1);
            Sleep(200);
        }


        if(mouse.singleLeftClick && mouse.y > 3 && mouse.x >= 154 && mouse.x < 158 && rightPannelOption == 1 && statSpot[mouse.y] != -1) /// Changing statMod Quants
        {
            if(statSpot[mouse.y] == -1)
            {
                break;
            }
            moveCursor(154,mouse.y);
            cout << "    ";
            moveCursor(154,mouse.y);

            string input;
            FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
            flush();
            getline(cin,input);
            player1.statModQuant[statSpot[mouse.y]][subStatSpot[mouse.y]] = stringToInt(input);
            saveCharacter(player1);
            Sleep(200);
            flush();
        }

        if(mouse.singleLeftClick && mouse.y > 3 && mouse.x > 157 && mouse.x < 160 && rightPannelOption == 1 && statSpot[mouse.y] != -1) /// Toggling statMods that are active (Left Click)
        {
            if(statSpot[mouse.y] == -1)
            {
                break;
            }

            if(player1.statModActive[statSpot[mouse.y]][subStatSpot[mouse.y]] != 1)
            {
                player1.statModActive[statSpot[mouse.y]][subStatSpot[mouse.y]] = 1;
            }
            else
            {
                player1.statModActive[statSpot[mouse.y]][subStatSpot[mouse.y]] = 0;
            }
            saveCharacter(player1);
            player1.addSpellPoints(0);
            player1.updateRealStats();
            player1.updateFinalSkillTotals();
            Sleep(150);
        }

        if(mouse.singleRightClick && mouse.y > 3 && mouse.x > 157 && mouse.x < 160 && rightPannelOption == 1 && statSpot[mouse.y] != -1) /// Toggling statMods that are active (Right Click)
        {
            if(statSpot[mouse.y] == -1)
            {
                break;
            }

            if(player1.statModActive[statSpot[mouse.y]][subStatSpot[mouse.y]] != 2)
            {
                player1.statModActive[statSpot[mouse.y]][subStatSpot[mouse.y]] = 2;
            }
            else
            {
                player1.statModActive[statSpot[mouse.y]][subStatSpot[mouse.y]] = 0;
            }
            saveCharacter(player1);
            player1.addSpellPoints(0);
            player1.updateRealStats();
            player1.updateFinalSkillTotals();
            Sleep(150);
        }



        for(int i = 0; i < 7; i++) /// DISPLAYING MENU OF ROLL RESULTS
        {
            moveCursor(56,40-3*i);
            cout << "           ";
            moveCursor(56,40-3*i);
            int charactersOutputted = 0;
            if(rollValues[i][0] != -500)
            {
                for(int x = 0; x < 8; x++)
                {
                    if(rollValues[i][x] != -500)
                    {
                        cout << rollValues[i][x];
                        if(rollValues[i][x] > 99)
                        {
                            charactersOutputted += 3;
                        }
                        if(rollValues[i][x] > 9 && rollValues[i][x] < 100)
                        {
                            charactersOutputted += 2;
                        }
                        if(rollValues[i][x] > -1 && rollValues[i][x] < 10)
                        {
                            charactersOutputted += 1;
                        }
                        if(rollValues[i][x] > -10 && rollValues[i][x] < 0)
                        {
                            charactersOutputted += 2;
                        }
                        if(rollValues[i][x] < -9)
                        {
                            charactersOutputted += 3;
                        }
                    }

                    if(x != 7)
                    {
                        if(rollValues[i][x+1] != -500)
                        {
                            cout << ", ";
                            charactersOutputted += 2;
                        }
                    }
                }

                string clearLine = "";
            for(int x = charactersOutputted; x < 27; x++)
            {
                clearLine += " ";
            }
            cout << clearLine;
                //cout << rollValues[i][0];

                SetConsoleTextAttribute( hStdOut, 0x44); // Dark Red

                if(rollValues[i][0] > 9)
                {
                    SetConsoleTextAttribute( hStdOut, 0xCC); // Red
                }
                if(rollValues[i][0] > 24)
                {
                    SetConsoleTextAttribute( hStdOut, 0x66); // Brown
                }
                if(rollValues[i][0] > 49)
                {
                    SetConsoleTextAttribute( hStdOut, 0xBB); // Light Blue
                }
                if(rollValues[i][0] > 74)
                {
                    SetConsoleTextAttribute( hStdOut, 0xAA); // Light Green
                }
                moveCursor(54, 40-3*i);
                cout << "X";
                moveCursor(54, 39-3*i);
                cout << "X";
                SetConsoleTextAttribute( hStdOut, 0x0F); // white
            }
            moveCursor(56,39-3*i);
            cout << "                     ";
            moveCursor(56,39-3*i);
            cout << rollSkillNames[i];
        }




        /// ROLLING LOGIC

        if(mouse.singleLeftClick || mouse.doubleClick)
        {
            if(mouse.x >= 125 && mouse.x < 155 && mouse.y >= 3 && mouse.y <= 41 && rightPannelOption == 0) /// SKILL ROLLS
            {
                updateRollHistory(roll(100) + player1.skillTotals[mouse.y - 3], GEN_SKILLS_NAMES[mouse.y - 3]);
            }
            if(mouse.x >= 70 && mouse.x <= 87 && mouse.y >= 10 && mouse.y <= 16) /// STAT ROLLS
            {
                updateRollHistory(roll(100) + player1.stats[mouse.y - 10], NAMES_OF_STATS[mouse.y - 10]);
            }
        }

        moveCursor(148,0); /// RIGHT SIDEBAR MENU SELECTOR

        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x00);
        cout << " ";

        SetConsoleTextAttribute( hStdOut, 0x0F);
        if(rightPannelOption == 0)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        cout << "Skills";

        ///

        moveCursor(148,1);
        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x00);
        cout << " ";

        SetConsoleTextAttribute( hStdOut, 0x0F);
        if(rightPannelOption == 1)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }

        cout << "Stat Modifiers";
        SetConsoleTextAttribute( hStdOut, 0x0F);

        /// /////////// LEFT SIDEBAR MENU SELECTOR
        moveCursor(6,0);
        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x00);
        cout << " ";

        SetConsoleTextAttribute( hStdOut, 0x0F);
        if(leftPannelOption == 0)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }
        cout << "Features";

        ///

        moveCursor(6,1);
        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";
        SetConsoleTextAttribute( hStdOut, 0x00);
        cout << " ";

        SetConsoleTextAttribute( hStdOut, 0x0F);
        if(leftPannelOption == 1)
        {
            SetConsoleTextAttribute( hStdOut, 0xF0);
        }

        cout << "Flurry Menu";
        SetConsoleTextAttribute( hStdOut, 0x0F);



        /// ///////////////
        if(mouse.singleLeftClick && mouse.x > 150 && mouse.y == 0) /// SWAPPING BETWEEN SKILLS AND STAT MOD MENUS
        {
            rightPannelOption = 0;
            goto playerStatPage;
        }
        if(mouse.singleLeftClick && mouse.x > 150 && mouse.y == 1)
        {
            rightPannelOption = 1;
            goto playerStatPage;
        }

        if(mouse.singleLeftClick && mouse.x > 6 && mouse.x < 25 && mouse.y == 0) /// SWAPPING BETWEEN ATTRIBUTES AND FLURRY MENU
        {
            leftPannelOption = 0;
            goto playerStatPage;
        }
        if(mouse.singleLeftClick && mouse.x > 6 && mouse.x < 25 && mouse.y == 1)
        {
            leftPannelOption = 1;
            goto playerStatPage;
        }


        /// /////////

        for(int i = 0; i < SIZE_OF_SKILL_NAMES; i++)
        {
            if(rightPannelOption != 0)
            {
                break;
            }
            moveCursor(155, i+3);
            if(player1.skillPips[i] == 1)
            {
                SetConsoleTextAttribute( hStdOut, 0x99);
                cout << "XX";
            }
            if(player1.skillPips[i] == 2)
            {
                SetConsoleTextAttribute( hStdOut, 0x44);
                cout << "XX";
            }
            if(player1.skillPips[i] == 0)
            {
                SetConsoleTextAttribute( hStdOut, 0x00);
                cout << "  ";
            }
        }
        SetConsoleTextAttribute( hStdOut, 0x0F);


        if(mouse.singleLeftClick && mouse.x > 154 && mouse.x < 160 && mouse.y > 2 && rightPannelOption == 0) /// LEFT CLICK PIP TOGGLE
        {
            if(player1.skillPips[mouse.y - 3] != 0)
            {
                player1.skillPips[mouse.y - 3] = 0;
            }
            else
            {
                player1.skillPips[mouse.y - 3] = 1;
            }
            saveCharacter(player1);
        }

        if(mouse.singleRightClick && mouse.x > 154 && mouse.x < 160 && mouse.y > 2 && rightPannelOption == 0) /// RIGHT CLICK PIP TOGGLE
        {
            if(player1.skillPips[mouse.y - 3] != 0)
            {
                player1.skillPips[mouse.y - 3] = 0;
            }
            else
            {
                player1.skillPips[mouse.y - 3] = 2;
            }
            saveCharacter(player1);
        }


        int flurryMenuX = 15;
        int flurryMenuY = 5;

        if(leftPannelOption == 1) /// FLURRY MENU
        {

            for(int i = 0; i < 7; i++)
            {
                int selectedSlot = 0;
                for(int x = 0; x < 6; x++)
                {
                    if(mouse.y == (flurryMenuY + 3 + 5*i))
                    {
                        //selectedSlot = 1;
                        if(mouse.x >= (flurryMenuX+4*x) && mouse.x < (flurryMenuX+4*x+3))
                        {
                            selectedSlot = x + 1;
                        }
                    }
                }

                displayRecoilHeader(flurryMenuX,flurryMenuY + 5*i,selectedSlot);
                moveCursor(flurryMenuX,flurryMenuY + 5*i);
                cout << player1.recoilName[i];
                moveCursor(flurryMenuX,flurryMenuY+1+ 5*i);
                cout << GEN_SKILLS_NAMES[player1.recoilSkill[i]] << "               ";
                ////cout << GEN_SKILLS_NAMES[3];
                moveCursor(flurryMenuX,flurryMenuY+2+ 5*i);
                cout << player1.recoilAmount[i];

                if(mouse.singleLeftClick && mouse.y == (flurryMenuY+3+ 5*i) && mouse.x < 50)
                {
                    rollRecoilAndUpdateHistory(player1, i, selectedSlot,1);
                }
                if(mouse.singleLeftClick && mouse.y == (flurryMenuY+1+ 5*i) && mouse.x < 25)
                {
                    player1.recoilSkill[i] = selectedSkill;
                    saveCharacter(player1);
                }
                if(mouse.singleLeftClick && mouse.y == (flurryMenuY + 5*i)&& mouse.x < 25)
                {
                    moveCursor(flurryMenuX,flurryMenuY+ 5*i);
                    cout << "                                  ";
                    moveCursor(flurryMenuX,flurryMenuY+ 5*i);
                    string input;
                    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
                    flush();
                    getline(cin,input);
                    player1.recoilName[i] = input;
                    saveCharacter(player1);
                    flush();
                    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
                }
                if(mouse.singleLeftClick && mouse.y == (flurryMenuY+2+ 5*i) && mouse.x < 25)
                {
                    moveCursor(flurryMenuX,flurryMenuY+2+ 5*i);
                    cout << "                ";
                    moveCursor(flurryMenuX,flurryMenuY+2+ 5*i);
                    string input;
                    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
                    flush();
                    getline(cin,input);
                    player1.recoilAmount[i] = stringToInt(input);
                    saveCharacter(player1);
                    flush();
                }
            }
        }

    }
}
Cyberware:
{

int typeOfAugment = 0;
int selectedAugment = 0;

moveCursor(47,3);
cout << "0  1  2  3  4  5  6  7  8  9";
displayAugmentSidebar(typeOfAugment);

CyberwareLater:
    ShowCursor(false);
    while(true)
    {
        resizeConsole();

        mouse.update();

        if(keyPressed(27))
        {
            goto menu;
        }

        //moveCursor(0,0);
        //cout << "       ";
        //moveCursor(0,0);
        //cout << mouse.x << " " << mouse.y;

        ShowCursor(false);

        displayAugmentDesc(83,5,typeOfAugment,selectedAugment,1);

        for(int i = 0; i < MENU_LIST_SIZE; i++)
        {
            if(i < augmentNames[typeOfAugment].size())
            {
                displayAugmentInfo(typeOfAugment,i,18,5+i,selectedAugment,player1);
            }
            else
            {
                moveCursor(18,5+i);
                cout << "                                                                ";
            }
        }

        if(mouse.y > 4 && mouse.y < (5 + augmentNames[typeOfAugment].size()) && mouse.x > 15 && mouse.x < 35)
        {
            moveCursor(0,2);
            //cout << mouse.y;
            selectedAugment = mouse.y - 5;
        }

        if(mouse.singleLeftClick)
        {
            if(mouse.x < 17 && mouse.y > 4)
            {
                for(int i = 0; i < 12; i++)
                {
                    if(mouse.y > (4+3*i) && mouse.y < (6+3*i))
                    {
                        typeOfAugment = i;
                        selectedAugment = 0;
                        displayAugmentSidebar(typeOfAugment);
                        break;
                    }
                }
            }
        }

        moveCursor(148,0);
        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";

        SetConsoleTextAttribute( hStdOut, 0x0F);
        cout << " Psionics";

        SetConsoleTextAttribute( hStdOut, 0x0F);
        moveCursor(148,1);

        SetConsoleTextAttribute( hStdOut, 0x77);
        cout << "X";

        SetConsoleTextAttribute( hStdOut, 0x0F);

        SetConsoleTextAttribute( hStdOut, 0x00);
        cout << " ";

        SetConsoleTextAttribute( hStdOut, 0xF0);

        cout << "Cyberware";

        SetConsoleTextAttribute( hStdOut, 0x0F);

        if(mouse.singleLeftClick && mouse.x > 149 && mouse.x < 156 && mouse.y == 0)
        {
            ClearScreen();
            goto playerMenuLater;
        }

        if(mouse.singleLeftClick && mouse.x > 18  && mouse.x < 40 && mouse.y > 4 && augmentPointCosts[typeOfAugment][selectedAugment] <= player1.spareSkillPoints && confirmPurchase(player1,augmentNames[typeOfAugment][selectedAugment]))
        {
            player1.augments[typeOfAugment].push_back(augmentNames[typeOfAugment][selectedAugment]);
            player1.augmentListSIMPLE.push_back(augmentNames[typeOfAugment][selectedAugment]);
            player1.augmentPointCosts[typeOfAugment].push_back(augmentPointCosts[typeOfAugment][selectedAugment]);
            player1.augmentSpiritCosts[typeOfAugment].push_back(augmentSpiritCosts[typeOfAugment][selectedAugment]);
            player1.augmentActive[typeOfAugment].push_back(true);

            player1.spareSkillPoints -= augmentPointCosts[typeOfAugment][selectedAugment];

            player1.cumulativeSpiritPenalty += augmentSpiritCosts[typeOfAugment][selectedAugment];

            saveCharacter(player1);
        }
        moveCursor(47,3);
        cout << "0  1  2  3  4  5  6  7  8  9";

        moveCursor(83,3);

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);

        //cout << " Spare Spell Points/Max Spell Points: " << player1.spareSkillPoints << "/" << player1.totalSkillPoints << " ";
        cout << " Points, Spare/Total: " << player1.spareSkillPoints << "/" << player1.totalSkillPoints << " ";

        SetConsoleTextAttribute(hStdOut, 0x88);
        cout << "X";
        SetConsoleTextAttribute(hStdOut, 0x0F);
        cout << "  ";

        //Sleep(20);
    }
}

newCharacter:
{
    ClearScreen();
    moveCursor(0,0);
    Sleep(500);
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));


    printScrollingTest("Hello, and welcome to the character creation interface. Hit SHIFT or SPACE at any time to speed up this dialog.",TEXT_SPEED);
    ShowConsoleCursor(true);
    cout << endl;
    printScrollingTest("This interface will allow you to input important character details to create a new character file. What this is not however,",TEXT_SPEED);
    cout << endl;
    printScrollingTest("is a comprehensive description of different character options and methods. For that you will have to reference the quick start",TEXT_SPEED);
    cout << endl;
    printScrollingTest("guide that should have been packaged with this program. ",TEXT_SPEED);

    cout << endl << endl;
    Sleep(200);

    printScrollingTest("To start the process, let's start with a name. What does your character call themselves?",TEXT_SPEED);
    cout << endl;

    string input;
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //cin >> input;
nameBreak:
    getline(cin,input);
    player1.name = input;

    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();

    printScrollingTest("You inputted: " + input + ", is this correct? (y/n)",TEXT_SPEED);
    cout << endl;

    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();

    getline(cin,input);
    if(input == "n")
    {
        printScrollingTest("I must have misheard, what was their name then?",TEXT_SPEED);
        cout << endl;
        FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
        flush();
        goto nameBreak;
    }

    cout << endl;
    printScrollingTest("Excellent. Now let me pry further.",TEXT_SPEED);
    cout << endl;
    //printScrollingTest("What race does " + player1.name + " belong to?",25);
    //cout << endl;

    //getline(cin,input);
    ///player1.race = input;

    //printScrollingTest("How old is " + player1.name + "?",40);
    //cout << endl;

    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();

    //getline(cin,input);
    //player1.age = stringToInt(input);

    printScrollingTest("What is your characters first color? (see section in quick start guide).",TEXT_SPEED);
    cout << endl;

    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();

    getline(cin,input);

    if(input == "White" || input == "white")
    {
        player1.colors[0] = true;
    }
    if(input == "Black" || input == "black")
    {
        player1.colors[1] = true;
    }
    if(input == "Blue" || input == "blue")
    {
        player1.colors[2] = true;
    }
    if(input == "Green" || input == "green")
    {
        player1.colors[3] = true;
    }
    if(input == "Red" || input == "red")
    {
        player1.colors[4] = true;
    }
    if(input == "Brown" || input == "brown")
    {
        player1.colors[5] = true;
    }

    printScrollingTest("What is your characters second color?",TEXT_SPEED);
    cout << endl;

    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();

    getline(cin,input);

    if(input == "White" || input == "white")
    {
        player1.colors[0] = true;
    }
    if(input == "Black" || input == "black")
    {
        player1.colors[1] = true;
    }
    if(input == "Blue" || input == "blue")
    {
        player1.colors[2] = true;
    }
    if(input == "Green" || input == "green")
    {
        player1.colors[3] = true;
    }
    if(input == "Red" || input == "red")
    {
        player1.colors[4] = true;
    }
    if(input == "Brown" || input == "brown")
    {
        player1.colors[5] = true;
    }

    //printScrollingTest("What is your first characteristic physical stat? (Power, Speed, or Dexterity?)",40);
    //cout << endl;
    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();
    //getline(cin,input);
    //player1.stats[returnStatNumber(input)] = 15;

    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();

    //printScrollingTest("What is your second characteristic physical stat? (Power, Speed, or Dexterity?)",40);
    //cout << endl;
    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();
    //getline(cin,input);
    //player1.stats[returnStatNumber(input)] = 10;

    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();

    //printScrollingTest("What is your first characteristic mental stat? (Intellectual, Perception, or Eloquence?)",40);
    //cout << endl;
    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();
    //getline(cin,input);
    //player1.stats[returnStatNumber(input)] = 15;

    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();

    //printScrollingTest("What is your second characteristic mental stat? (Intellectual, Perception, or Eloquence?)",40);
    //cout << endl;
    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();
    //getline(cin,input);
    //player1.stats[returnStatNumber(input)] = 10;


    cout << endl;
    printScrollingTest("Do you wish to use standard or mixed backgrounds?",TEXT_SPEED);
    cout << endl;
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();
    getline(cin,input);

    if(input == "mixed" || input == "Mixed")
    {
        goto mixedBackground;
        cout << endl;
    }


    background:

    cout << endl;
    printScrollingTest("What is your characters background?",TEXT_SPEED);
    cout << endl;
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();
    getline(cin,input);

    if(player1.loadBackground(input) != true)
    {
        cout << endl;
        printScrollingTest("Sorry, that wasn't a valid input",TEXT_SPEED);
        goto background;
    }

    goto kit;

mixedBackground:

    cout << endl;
    printScrollingTest("Primary Background?",TEXT_SPEED);
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    cout << endl;
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();
    getline(cin,input);
    player1.spliceFile("../Threadlinkers Assistant/Characters/Backgrounds/", input, 0.75, false);

    cout << endl;
    printScrollingTest("Secondary Background?",TEXT_SPEED);
    cout << endl;
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();
    getline(cin,input);
    player1.spliceFile("../Threadlinkers Assistant/Characters/Backgrounds/", input, 0.5, true);


kit:

    cout << endl;
    printScrollingTest("Finally, what starting kit would you like for your character? (1,2,3, or 4. See quick start guide)",TEXT_SPEED);
    cout << endl;
    //printScrollingTest("Casters are users of a not well understood form of magic. Their powers are defined by their ",40);
    //cout << endl;
    //printScrollingTest("personality and life-philosophy. Their powers are most potent when they use little cybernetics",40);
    //cout << endl;
    //printScrollingTest("so those who discover these powers within themselves typically lack extensive modifications.",40);
    //cout << endl << endl;
    //FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //flush();


    bool ask = true;

    while(true)
    {
        cout << endl;
        if(ask)
        {
            printScrollingTest("So what shall it be?",TEXT_SPEED);
            ask = false;
            cout << endl;
        }
        FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
        flush();
        getline(cin,input);

        if(input == "caster" || input == "Caster" || input == "1")
        {
            player1.spliceFile("../Threadlinkers Assistant/Characters/Kits/", "kit 1", 1, false);
            SetConsoleTextAttribute( hStdOut, 0x0F);
            player1.casterStart = true;
            player1.startingKit = 1;
            printScrollingTest("Alright, you will now be sent to the spell menu. Your first two cantrips and 1st-level spells",TEXT_SPEED);
            cout << endl;
            //Sleep(200);
            printScrollingTest("represent important developments in your past, therefore they are free.",TEXT_SPEED);
            cout << endl;
            Sleep(100);
            break;
        }

        //bool ttt = false;

        //for(int i = 2; i < 10; i++) //
        //{
            //if(input == simpleIntToString(i))
            //{

        //if(input == "1")
        //{
            //player1.spliceFile("../Threadlinkers Assistant/Characters/Kits/", "kit " + input, 1, false);
            //break;
        //}


        if(input == "2")
        {
            player1.spliceFile("../Threadlinkers Assistant/Characters/Kits/", "kit " + input, 1, false);
            player1.startingKit = 2;

            //for(int i = 0; i < 6; i++)
            //{
                //player1.stats[i] = player1.stats[i] * 1.25;
            //}
            for(int i = 0; i < SIZE_OF_SKILL_NAMES; i++)
            {
                player1.skills[i] = player1.skills[i] * 1.25;
            }
            break;
        }
        if(input == "3")
        {
            player1.spliceFile("../Threadlinkers Assistant/Characters/Kits/", "kit " + input, 1, false);
            player1.startingKit = 3;
            break;
        }
        if(input == "4")
        {
            player1.spliceFile("../Threadlinkers Assistant/Characters/Kits/", "kit " + input, 1, false);
            player1.startingKit = 4;
            break;
        }
        if(input == "5")
        {
            player1.spliceFile("../Threadlinkers Assistant/Characters/Kits/", "kit " + input, 1, false);
            player1.startingKit = 5;
            break;
        }
        if(input == "6")
        {
            player1.spliceFile("../Threadlinkers Assistant/Characters/Kits/", "kit " + input, 1, false);
            player1.startingKit = 6;
            break;
        }
        printScrollingTest("Sorry, that wasn't a valid input. Could you try again?",40);
        cout << endl;
    }

    cout << endl;



    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    flush();

    SetConsoleTextAttribute( hStdOut, 0x0F);
    moveCursor(0,0);

    //cout << "first flag" << endl;

    player1.spareSkillPoints = 100;
    player1.totalSkillPoints = 100;

    saveCharacter(player1);

    addNameToCharacterList(player1.name);

    ShowConsoleCursor(false);

    //cout << "PlayerMenu Flag" << endl;

    goto playerMenu;

    return 0;
}
}
