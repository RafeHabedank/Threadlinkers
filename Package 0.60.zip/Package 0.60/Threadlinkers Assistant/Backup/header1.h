//https://www.tutorialspoint.com/cprogramming/c_header_files.html
//https://stackoverflow.com/questions/17904643/error-with-multiple-definitions-of-function

#ifndef HEADER_FILE
#define HEADER_FILE

#define _WIN32_WINNT 0x0500

#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <math.h>
#include <vector>


const int NUMBER_OF_COLORS = 6;



void ClearScreen();
void moveCursor(int posX, int posY);
int getKey();
int waitForKey();
bool keyPressed(int input);

std::string cutString(std::string source, int startPos, int endPos);
std::string simpleIntToString(int input);
int stringToInt(std::string input);
int getCost(std::string spellName, int spellLevel, bool playerColors[6], std::vector<std::string> knownSpells);

void loadSpells();


class player
{
public:

    std::string name;
    std::string race;
    int age;
    int totalSkillPoints;
    int spareSkillPoints;

    int spareStatPoints = 0;
    int maxHealth = 10;

    bool colors[6] = {false,false,false,false,false,false};
    std::vector<std::string> spells[10];
    std::vector<int> spellCosts[10];

    int spellSlots[10] = {2,1,0,0,0,0,0,0,0,0};

    std::vector<std::string> spellListSIMPLE; // A more simple list of all spells, unorganized, for supplement calculation in getCost()

    void loadData();
    void displayStats(int xPos, int yPos);
    bool addSpellPoints(int numberAdded);
    void displayKnownSpells(int xPos, int yPos);

    int stats[7] = {50,50,50,50,50,50,50};
    std::string statNames[7] = {"Power","Speed","Dexterity","Intellectual","Perception","Eloquence","Spirit"};




};

#endif
